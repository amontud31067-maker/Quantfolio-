"""
QuantFolio Pro - High Performance Portfolio Optimization Engine
Production-hardened with Thread-Safety & Multi-User TTL Caching
"""

import os
import re
import time
import tempfile
import threading
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
import requests
import numpy as np
import pandas as pd

# Ensure matplotlib and yfinance caches have a writable directory inside cloud containers
os.environ.setdefault("MPLCONFIGDIR", os.path.join(tempfile.gettempdir(), "mpl_cache"))

import yfinance as yf
from typing import List, Dict, Any, Optional, Tuple

# Use PyPortfolioOpt + SciPy when installed locally/Docker, with built-in pure NumPy/Pandas fallback for Vercel Serverless (<250MB limit)
try:
    import scipy.cluster.hierarchy as sch
    if not hasattr(sch, '_LINKAGE_METHODS'):
        sch._LINKAGE_METHODS = {
            'single': 0, 'complete': 1, 'average': 2, 'centroid': 3,
            'median': 4, 'ward': 5, 'weighted': 6
        }
    from pypfopt import expected_returns, risk_models, EfficientFrontier, HRPOpt
    from pypfopt import DiscreteAllocation, get_latest_prices
    
    # Patch pypfopt mean_historical_return to safely handle frequency=None (Exact Calendar CAGR)
    _pypfopt_mhr = expected_returns.mean_historical_return
    def _safe_mhr(prices: pd.DataFrame, frequency: Optional[int] = None, **kwargs) -> pd.Series:
        if frequency is None:
            if isinstance(prices.index, pd.DatetimeIndex) and len(prices.index) >= 2:
                cal_days = max(1.0, float((prices.index[-1] - prices.index[0]).days))
                years = cal_days / 365.25
                first_prices = prices.bfill().iloc[0]
                last_prices = prices.ffill().iloc[-1]
                return (last_prices / first_prices) ** (1.0 / years) - 1.0
            frequency = 252
        return _pypfopt_mhr(prices, frequency=frequency, **kwargs)
    expected_returns.mean_historical_return = _safe_mhr
except ImportError:
    def get_latest_prices(prices: pd.DataFrame) -> pd.Series:
        return prices.ffill().iloc[-1]

    class expected_returns:
        @staticmethod
        def mean_historical_return(prices: pd.DataFrame, frequency: Optional[int] = None) -> pd.Series:
            rets = prices.pct_change().dropna(how="all")
            if len(rets) == 0:
                return pd.Series(0.0, index=prices.columns)
            if frequency is None and isinstance(prices.index, pd.DatetimeIndex) and len(prices.index) >= 2:
                cal_days = max(1.0, float((prices.index[-1] - prices.index[0]).days))
                years = cal_days / 365.25
                first_prices = prices.bfill().iloc[0]
                last_prices = prices.ffill().iloc[-1]
                return (last_prices / first_prices) ** (1.0 / years) - 1.0
            freq = float(frequency or 252)
            return (1.0 + rets).prod() ** (freq / len(rets)) - 1.0

    class risk_models:
        class CovarianceShrinkage:
            def __init__(self, prices: pd.DataFrame, frequency: int = 252):
                self.rets = prices.pct_change().dropna()
                self.frequency = frequency

            def ledoit_wolf(self) -> pd.DataFrame:
                X = self.rets.values
                t, n = X.shape
                if t <= 1:
                    return pd.DataFrame(np.eye(n) * 0.04, index=self.rets.columns, columns=self.rets.columns)
                X_centered = X - X.mean(axis=0, keepdims=True)
                sample_cov = (X_centered.T @ X_centered) / (t - 1)
                if n <= 1:
                    return pd.DataFrame(sample_cov * self.frequency, index=self.rets.columns, columns=self.rets.columns)
                mu_tr = np.trace(sample_cov) / n
                F = np.eye(n) * mu_tr
                # Analytical Ledoit-Wolf optimal shrinkage intensity (avoids hardcoded delta = 0.15 bias)
                X2 = X_centered ** 2
                sum_sq_cov_diff = float(np.sum((X2.T @ X2) / t - sample_cov ** 2)) / t
                misspecification = float(np.sum((sample_cov - F) ** 2))
                if misspecification > 1e-16:
                    delta = float(np.clip(sum_sq_cov_diff / misspecification, 0.0, 1.0))
                else:
                    delta = 0.0
                shrunk = (1.0 - delta) * sample_cov + delta * F
                return pd.DataFrame(shrunk * self.frequency, index=self.rets.columns, columns=self.rets.columns)

        @staticmethod
        def cov_to_corr(S: pd.DataFrame) -> pd.DataFrame:
            std = np.sqrt(np.diag(S.values))
            std_safe = np.where(std > 0, std, 1.0)
            corr = S.values / np.outer(std_safe, std_safe)
            np.fill_diagonal(corr, 1.0)
            return pd.DataFrame(np.clip(corr, -1.0, 1.0), index=S.index, columns=S.columns)

    def _project_capped_simplex(v: np.ndarray, low: float, high: float) -> np.ndarray:
        n = len(v)
        low = max(0.0, float(low))
        high = min(1.0, max(float(high), 1.0 / n + 1e-6))
        v_list = v.tolist() if hasattr(v, "tolist") else [float(x) for x in v]
        lo_lam = min(v_list) - high
        hi_lam = max(v_list) - low
        for _ in range(50):
            mid = 0.5 * (lo_lam + hi_lam)
            s = 0.0
            for x in v_list:
                val = x - mid
                if val < low:
                    s += low
                elif val > high:
                    s += high
                else:
                    s += val
            if s > 1.0:
                lo_lam = mid
            else:
                hi_lam = mid
            if hi_lam - lo_lam <= 1e-13:
                break
        lam = 0.5 * (lo_lam + hi_lam)
        w = np.clip(np.asarray(v, dtype=float) - lam, low, high)
        w_sum = float(w.sum())
        return w / w_sum if w_sum > 0 else np.ones(n) / n

    def _project_capped_simplex_batch(V: np.ndarray, low: float, high: float) -> np.ndarray:
        """Vectorized row-wise capped simplex projection (mathematically identical to _project_capped_simplex)."""
        V = np.asarray(V, dtype=float)
        _, n = V.shape
        low = max(0.0, float(low))
        high = min(1.0, max(float(high), 1.0 / n + 1e-6))
        if low <= 0.0 and high >= 1.0:
            row_sums = V.sum(axis=1)
            if np.all(V >= 0.0) and np.all(np.abs(row_sums - 1.0) <= 1e-12):
                return V.copy()
        lo_lam = np.min(V, axis=1) - high
        hi_lam = np.max(V, axis=1) - low
        for _ in range(50):
            mid = 0.5 * (lo_lam + hi_lam)
            s = np.clip(V - mid[:, None], low, high).sum(axis=1)
            gt = s > 1.0
            lo_lam = np.where(gt, mid, lo_lam)
            hi_lam = np.where(gt, hi_lam, mid)
            if float(np.max(hi_lam - lo_lam)) <= 1e-13:
                break
        W = np.clip(V - (0.5 * (lo_lam + hi_lam))[:, None], low, high)
        W_sum = W.sum(axis=1, keepdims=True)
        return np.where(W_sum > 0.0, W / np.where(W_sum > 0.0, W_sum, 1.0), 1.0 / n)

    class EfficientFrontier:
        def __init__(self, mu: pd.Series, S: pd.DataFrame, weight_bounds: Tuple[float, float] = (0.0, 1.0)):
            self.tickers = list(mu.index)
            self.mu = mu.values.astype(float)
            self.S = S.loc[self.tickers, self.tickers].values.astype(float)
            self.low, self.high = float(weight_bounds[0]), float(weight_bounds[1])
            self.w = np.ones(len(self.tickers)) / len(self.tickers)

        def min_volatility(self):
            n = len(self.tickers)
            w = _project_capped_simplex(np.ones(n) / n, self.low, self.high)
            # Gradient of w'Sw is 2Sw -> Lipschitz constant 2*||S||, so a safe projected-GD step is 1/(2*||S||)
            step = 0.5 / (float(np.linalg.norm(self.S, ord=2)) + 1e-6)
            for _ in range(350):
                grad = 2.0 * (self.S @ w)
                w_next = _project_capped_simplex(w - step * grad, self.low, self.high)
                if float(np.max(np.abs(w_next - w))) < 1e-9:
                    w = w_next
                    break
                w = w_next
            self.w = w
            return self.clean_weights()

        def max_sharpe(self, risk_free_rate: float = 0.04):
            n = len(self.tickers)
            rng = np.random.default_rng(42)
            W_cand = _project_capped_simplex_batch(rng.dirichlet(np.ones(n), 2500), self.low, self.high)
            rets = W_cand @ self.mu
            vols = np.sqrt(np.maximum(1e-12, np.einsum('ij,jk,ik->i', W_cand, self.S, W_cand)))
            srs = (rets - risk_free_rate) / vols
            w = W_cand[int(np.argmax(srs))].copy()
            for it in range(300):
                port_ret = float(w @ self.mu) - risk_free_rate
                port_var = max(1e-12, float(w @ self.S @ w))
                port_vol = np.sqrt(port_var)
                grad = (self.mu * port_vol - port_ret * (self.S @ w) / port_vol) / port_var
                lr = 0.15 / (1.0 + 0.02 * it)
                w_new = _project_capped_simplex(w + lr * grad, self.low, self.high)
                sr_old = port_ret / port_vol
                sr_new = (float(w_new @ self.mu) - risk_free_rate) / np.sqrt(max(1e-12, float(w_new @ self.S @ w_new)))
                if sr_new >= sr_old:
                    w = w_new
            self.w = w
            return self.clean_weights()

        def efficient_return(self, target_return: float):
            n = len(self.tickers)
            w = _project_capped_simplex(np.ones(n) / n, self.low, self.high)
            norm_s = float(np.linalg.norm(self.S, ord=2)) + 1e-6
            penalty = 25.0 * norm_s
            # Lipschitz constant of the gradient is 2*(||S|| + penalty*||mu||^2) -> step = 1/L
            step = 0.5 / (norm_s + penalty * float(np.dot(self.mu, self.mu)) + 1e-6)
            for _ in range(350):
                diff = float(w @ self.mu) - target_return
                grad = 2.0 * (self.S @ w) + 2.0 * penalty * diff * self.mu
                w_next = _project_capped_simplex(w - step * grad, self.low, self.high)
                if float(np.max(np.abs(w_next - w))) < 1e-9:
                    w = w_next
                    break
                w = w_next
            self.w = w
            return self.clean_weights()

        def efficient_return_batch(self, target_returns: np.ndarray, risk_free_rate: float = 0.04) -> List[Dict[str, float]]:
            """Vectorized simultaneous efficient_return solver across all frontier targets (identical math)."""
            targets = np.asarray(target_returns, dtype=float)
            m = len(targets)
            n = len(self.tickers)
            if m == 0 or n == 0:
                return []
            w0 = _project_capped_simplex(np.ones(n) / n, self.low, self.high)
            W = np.repeat(w0[None, :], m, axis=0)
            norm_s = float(np.linalg.norm(self.S, ord=2)) + 1e-6
            penalty = 25.0 * norm_s
            step = 0.5 / (norm_s + penalty * float(np.dot(self.mu, self.mu)) + 1e-6)
            for _ in range(350):
                diffs = (W @ self.mu) - targets
                grad = 2.0 * (W @ self.S) + (2.0 * penalty) * diffs[:, None] * self.mu[None, :]
                W_next = _project_capped_simplex_batch(W - step * grad, self.low, self.high)
                if float(np.max(np.abs(W_next - W))) < 1e-9:
                    W = W_next
                    break
                W = W_next
            rets = W @ self.mu
            vols = np.sqrt(np.maximum(1e-12, np.einsum('ij,jk,ik->i', W, self.S, W)))
            srs = np.where(vols > 0.0, (rets - risk_free_rate) / vols, 0.0)
            return [
                {
                    "vol": round(float(vols[i]), 4),
                    "ret": round(float(rets[i]), 4),
                    "sharpe": round(float(srs[i]), 3)
                }
                for i in range(m)
            ]

        def clean_weights(self) -> Dict[str, float]:
            w_clean = np.where(self.w < 1e-4, 0.0, self.w)
            s = w_clean.sum()
            if s > 0:
                w_clean = w_clean / s
            return {self.tickers[i]: round(float(w_clean[i]), 5) for i in range(len(self.tickers))}

        def portfolio_performance(self, risk_free_rate: float = 0.04) -> Tuple[float, float, float]:
            ret = float(self.w @ self.mu)
            vol = float(np.sqrt(max(1e-12, self.w @ self.S @ self.w)))
            sr = (ret - risk_free_rate) / vol if vol > 0 else 0.0
            return ret, vol, sr

    class HRPOpt:
        def __init__(self, returns_df: pd.DataFrame, frequency: int = 252):
            self.returns_df = returns_df
            self.frequency = frequency

        def optimize(self) -> Dict[str, float]:
            tickers = list(self.returns_df.columns)
            n = len(tickers)
            cov = self.returns_df.cov().values * float(self.frequency)
            std = np.sqrt(np.maximum(1e-12, np.diag(cov)))
            corr = np.clip(cov / np.outer(std, std), -1.0, 1.0)
            dist = np.sqrt(np.maximum(0.0, 0.5 * (1.0 - corr)))
            visited = [int(np.argmin(dist.sum(axis=1)))]
            while len(visited) < n:
                last = visited[-1]
                best_j, best_d = -1, 1e9
                for j in range(n):
                    if j not in visited and dist[last, j] < best_d:
                        best_d = dist[last, j]
                        best_j = j
                visited.append(best_j)
            w = np.ones(n)
            clusters = [visited]
            while clusters:
                next_clusters = []
                for c in clusters:
                    if len(c) <= 1:
                        continue
                    mid = len(c) // 2
                    c1, c2 = c[:mid], c[mid:]
                    v1 = self._cluster_var(cov, c1)
                    v2 = self._cluster_var(cov, c2)
                    alpha = 1.0 - v1 / (v1 + v2) if (v1 + v2) > 0 else 0.5
                    for idx in c1:
                        w[idx] *= alpha
                    for idx in c2:
                        w[idx] *= (1.0 - alpha)
                    if len(c1) > 1:
                        next_clusters.append(c1)
                    if len(c2) > 1:
                        next_clusters.append(c2)
                clusters = next_clusters
            w = w / w.sum() if w.sum() > 0 else np.ones(n) / n
            return {tickers[i]: round(float(w[i]), 5) for i in range(n)}

        @staticmethod
        def _cluster_var(cov: np.ndarray, idxs: List[int]) -> float:
            sub_cov = cov[np.ix_(idxs, idxs)]
            ivp = 1.0 / np.maximum(1e-12, np.diag(sub_cov))
            ivp /= ivp.sum()
            return float(ivp @ sub_cov @ ivp)

    class DiscreteAllocation:
        def __init__(self, weights: Dict[str, float], latest_prices: pd.Series, total_portfolio_value: float = 100000.0):
            self.weights = weights
            self.prices = latest_prices
            self.total_val = float(total_portfolio_value)

        def greedy_portfolio(self) -> Tuple[Dict[str, int], float]:
            shares: Dict[str, int] = {}
            available = self.total_val
            for t, w in self.weights.items():
                p = float(self.prices[t])
                if p > 0 and w > 0:
                    n = int((w * self.total_val) // p)
                    if n > 0:
                        shares[t] = n
                        available -= n * p
            while True:
                affordable = [t for t in self.weights if 0 < float(self.prices[t]) <= available]
                if not affordable:
                    break
                spent = self.total_val - available
                best_t = max(
                    affordable,
                    key=lambda t: self.weights[t] - (shares.get(t, 0) * float(self.prices[t]) / max(1.0, spent))
                )
                shares[best_t] = shares.get(best_t, 0) + 1
                available -= float(self.prices[best_t])
            return shares, round(available, 2)

# Set dedicated cache directory for yfinance in temp dir to prevent SQLite locking & permission issues
CACHE_DIR = os.path.join(tempfile.gettempdir(), 'quantfolio_yf_cache')
try:
    os.makedirs(CACHE_DIR, exist_ok=True)
    yf.set_tz_cache_location(CACHE_DIR)
except Exception:
    pass

TRADING_DAYS = 252

# Thread lock & in-memory TTL caches for multi-user concurrency
_yf_lock = threading.Lock()
_news_cache_lock = threading.Lock()
_compute_cache_lock = threading.Lock()
_price_cache: Dict[Tuple, Tuple[float, pd.DataFrame, List[str], List[str]]] = {}
_rf_cache: Dict[str, Tuple[float, float]] = {}
_fx_cache: Dict[str, Tuple[float, float]] = {}
_news_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}
_wf_cache: Dict[Tuple, Tuple[float, Dict[str, pd.Series]]] = {}
_frontier_cache: Dict[Tuple, Tuple[float, List[Dict[str, float]]]] = {}
_fx_meta: Dict[str, Dict[str, Any]] = {}
_rf_meta: Dict[str, Dict[str, Any]] = {}

PRICE_CACHE_TTL = 900    # 15 minutes
COMPUTE_CACHE_TTL = 900  # 15 minutes
RF_CACHE_TTL = 3600      # 1 hour
FX_CACHE_TTL = 1800      # 30 minutes
NEWS_CACHE_TTL = 600     # 10 minutes

# Well-known asset display names for institutional look
KNOWN_NAMES = {
    'NVDA': 'NVIDIA Corp.',
    'AAPL': 'Apple Inc.',
    'MSFT': 'Microsoft Corp.',
    'AMZN': 'Amazon.com Inc.',
    'TSLA': 'Tesla Inc.',
    'GOOGL': 'Alphabet Inc.',
    'GOOG': 'Alphabet Inc.',
    'META': 'Meta Platforms Inc.',
    'BRK-B': 'Berkshire Hathaway',
    'JPM': 'JPMorgan Chase & Co.',
    'V': 'Visa Inc.',
    'JNJ': 'Johnson & Johnson',
    'WMT': 'Walmart Inc.',
    'PG': 'Procter & Gamble',
    'MA': 'Mastercard Inc.',
    'KO': 'Coca-Cola Co.',
    'PEP': 'PepsiCo Inc.',
    'COST': 'Costco Wholesale',
    'AVGO': 'Broadcom Inc.',
    'AMD': 'Advanced Micro Devices',
    'NFLX': 'Netflix Inc.',
    'DIS': 'Walt Disney Co.',
    'SPY': 'SPDR S&P 500 ETF',
    'QQQ': 'Invesco QQQ Trust',
    'VOO': 'Vanguard S&P 500 ETF',
    'VTI': 'Vanguard Total Stock ETF',
    'GLD': 'SPDR Gold Shares ETF',
    'SLV': 'iShares Silver Trust',
    'TLT': 'iShares 20+ Yr Treasury ETF',
    'BND': 'Vanguard Total Bond ETF',
    'VNQ': 'Vanguard Real Estate ETF',
    'DBC': 'Invesco DB Commodity ETF',
    'BTC-USD': 'Bitcoin (USD)',
    'ETH-USD': 'Ethereum (USD)',
    'SOL-USD': 'Solana (USD)',
    'BNB-USD': 'BNB (USD)',
    'PTT.BK': 'บมจ. ปตท. (PTT)',
    'AOT.BK': 'บมจ. ท่าอากาศยานไทย (AOT)',
    'CPALL.BK': 'บมจ. ซีพี ออลล์ (CPALL)',
    'DELTA.BK': 'บมจ. เดลต้า อีเลคโทรนิคส์ (DELTA)',
    'BDMS.BK': 'บมจ. กรุงเทพดุสิตเวชการ (BDMS)',
    'ADVANC.BK': 'บมจ. แอดวานซ์ อินโฟร์ เซอร์วิส (AIS)',
    'SCB.BK': 'บมจ. เอสซีบี เอกซ์ (SCBX)',
    'KBANK.BK': 'บมจ. ธนาคารกสิกรไทย (KBANK)',
    'BBL.BK': 'บมจ. ธนาคารกรุงเทพ (BBL)',
    'PTTEP.BK': 'บมจ. ปตท.สผ. (PTTEP)',
    'SCC.BK': 'บมจ. ปูนซิเมนต์ไทย (SCG)',
    'GULF.BK': 'บมจ. กัลฟ์ เอ็นเนอร์จี (GULF)',
    'CPN.BK': 'บมจ. เซ็นทรัลพัฒนา (CPN)',
    'BH.BK': 'บมจ. โรงพยาบาลบำรุงราษฎร์ (BH)',
    'MINT.BK': 'บมจ. ไมเนอร์ อินเตอร์เนชั่นแนล (MINT)',
    'TISCO.BK': 'บมจ. ทิสโก้ไฟแนนเชียลกรุ๊ป (TISCO)',
    'LH.BK': 'บมจ. แลนด์ แอนด์ เฮ้าส์ (LH)',
    'INTUCH.BK': 'บมจ. อินทัช โฮลดิ้งส์ (INTUCH)'
}

KNOWN_DIVIDEND_YIELDS = {
    'NVDA': 0.0003,
    'AAPL': 0.0052,
    'MSFT': 0.0072,
    'AMZN': 0.0,
    'TSLA': 0.0,
    'GOOGL': 0.0045,
    'GOOG': 0.0045,
    'META': 0.0038,
    'BRK-B': 0.0,
    'JPM': 0.0215,
    'V': 0.0078,
    'JNJ': 0.0315,
    'WMT': 0.0110,
    'PG': 0.0240,
    'MA': 0.0058,
    'KO': 0.0310,
    'PEP': 0.0305,
    'COST': 0.0055,
    'AVGO': 0.0130,
    'AMD': 0.0,
    'NFLX': 0.0,
    'DIS': 0.0085,
    'SPY': 0.0128,
    'QQQ': 0.0058,
    'VOO': 0.0132,
    'VTI': 0.0135,
    'GLD': 0.0,
    'SLV': 0.0,
    'TLT': 0.0385,
    'BND': 0.0345,
    'VNQ': 0.0390,
    'DBC': 0.0210,
    'BTC-USD': 0.0,
    'ETH-USD': 0.0,
    'SOL-USD': 0.0,
    'BNB-USD': 0.0,
    'PTT.BK': 0.0585,
    'AOT.BK': 0.0125,
    'CPALL.BK': 0.0175,
    'DELTA.BK': 0.0065,
    'BDMS.BK': 0.0245,
    'ADVANC.BK': 0.0410,
    'SCB.BK': 0.0740,
    'KBANK.BK': 0.0460,
    'BBL.BK': 0.0480,
    'PTTEP.BK': 0.0620,
    'SCC.BK': 0.0280,
    'GULF.BK': 0.0195,
    'CPN.BK': 0.0285,
    'BH.BK': 0.0210,
    'MINT.BK': 0.0180,
    'TISCO.BK': 0.0785,
    'LH.BK': 0.0650,
    'INTUCH.BK': 0.0490
}


def get_estimated_dividend_yield(ticker: str) -> float:
    t = ticker.strip().upper()
    if t in KNOWN_DIVIDEND_YIELDS:
        return KNOWN_DIVIDEND_YIELDS[t]
    if t.endswith('-USD'):
        return 0.0
    if t.endswith('.BK'):
        return 0.0320
    return 0.0120


def get_asset_name(ticker: str) -> str:
    return KNOWN_NAMES.get(ticker.upper(), ticker.upper())


def get_ticker_currency(ticker: str) -> str:
    """Identify native trading currency of ticker (.BK -> THB, others -> USD)."""
    return "THB" if ticker.strip().upper().endswith(".BK") else "USD"


_last_fx_is_fallback: bool = False
_last_rf_is_fallback: bool = False
THB_RISK_FREE_RATE_DEFAULT: float = 0.0225  # Thai Government Bond / BOT reference rate (2.25%)


def get_asset_market_type(ticker: str) -> str:
    t = str(ticker or "").strip().upper()
    if t.endswith(".BK"):
        return "equity_th"
    if t.endswith("-USD"):
        return "crypto"
    return "equity_us"


def get_usd_thb_rate(default_rate: float = 34.50) -> float:
    """Fetch current USD/THB exchange rate (THB=X) from Yahoo Finance with 30-minute cache."""
    global _last_fx_is_fallback
    now = time.time()
    if 'usd_thb' in _fx_cache:
        ts, cached_val = _fx_cache['usd_thb']
        if now - ts < FX_CACHE_TTL:
            _last_fx_is_fallback = False
            return cached_val

    try:
        with _yf_lock:
            fx_df = yf.download('THB=X', period='5d', auto_adjust=True, progress=False)['Close']
        if not fx_df.empty:
            clean = fx_df.dropna()
            if not clean.empty:
                val = clean.iloc[-1]
                latest = float(val.values[0]) if hasattr(val, 'values') else float(val)
                if 20.0 <= latest <= 60.0:
                    rate = round(latest, 2)
                    last_dt = clean.index[-1]
                    fx_date = last_dt.strftime('%Y-%m-%d') if hasattr(last_dt, 'strftime') else str(last_dt)
                    _fx_cache['usd_thb'] = (now, rate)
                    _fx_meta['usd_thb'] = {
                        "fx_date": fx_date,
                        "fx_updated_at": datetime.now(timezone.utc).isoformat(),
                        "is_fallback_fx": False,
                    }
                    _last_fx_is_fallback = False
                    return rate
    except Exception as e:
        print(f"Notice: Failed to fetch THB=X ({e}), using fallback {default_rate:.2f} without caching")

    # Do NOT cache fallback rate so next request retries live data
    _last_fx_is_fallback = True
    _fx_meta['usd_thb'] = {
        "fx_date": None,
        "fx_updated_at": datetime.now(timezone.utc).isoformat(),
        "is_fallback_fx": True,
    }
    return default_rate


def get_risk_free_rate(default_rate: float = 0.04, currency: str = "USD") -> float:
    """
    Fetch risk-free rate matched to the portfolio's base currency:
    - THB: Thai Government Bond / BOT policy reference rate (~2.25%)
    - USD: 13-week US Treasury Bill yield (^IRX) with 1-hour cache
    """
    global _last_rf_is_fallback
    curr = (currency or "USD").strip().upper()
    if curr == "THB":
        _last_rf_is_fallback = False
        _rf_meta["THB"] = {
            "risk_free_source": "BOT / พันธบัตรรัฐบาลไทย (ค่าอ้างอิงในระบบ)",
            "risk_free_tenor": "อ้างอิงคงที่ในระบบ",
            "risk_free_date": None,
            "rf_updated_at": datetime.now(timezone.utc).isoformat(),
            "is_fallback_rf": False,
        }
        return THB_RISK_FREE_RATE_DEFAULT

    now = time.time()
    if 'rf_usd' in _rf_cache:
        ts, cached_val = _rf_cache['rf_usd']
        if now - ts < RF_CACHE_TTL:
            _last_rf_is_fallback = False
            return cached_val

    try:
        with _yf_lock:
            irx = yf.download('^IRX', period='1mo', auto_adjust=True, progress=False)['Close']
        if not irx.empty:
            clean = irx.dropna()
            if not clean.empty:
                val = clean.iloc[-1]
                latest = float(val.values[0]) if hasattr(val, 'values') else float(val)
                rate = round(latest / 100.0, 4)
                last_dt = clean.index[-1]
                rf_date = last_dt.strftime('%Y-%m-%d') if hasattr(last_dt, 'strftime') else str(last_dt)
                _rf_cache['rf_usd'] = (now, rate)
                _rf_meta["USD"] = {
                    "risk_free_source": "US 13W Treasury Bill (^IRX)",
                    "risk_free_tenor": "13 สัปดาห์",
                    "risk_free_date": rf_date,
                    "rf_updated_at": datetime.now(timezone.utc).isoformat(),
                    "is_fallback_rf": False,
                }
                _last_rf_is_fallback = False
                return rate
    except Exception as e:
        print(f"Notice: Failed to fetch ^IRX ({e}), using fallback {default_rate:.2%} without caching")

    # Do NOT cache fallback rate so next request retries live data
    _last_rf_is_fallback = True
    _rf_meta["USD"] = {
        "risk_free_source": "US Treasury (ค่าสำรองในระบบ)",
        "risk_free_tenor": "13 สัปดาห์ (สำรอง)",
        "risk_free_date": None,
        "rf_updated_at": datetime.now(timezone.utc).isoformat(),
        "is_fallback_rf": True,
    }
    return default_rate


def get_market_rates_metadata(currency: str = "USD") -> Dict[str, Any]:
    """Return latest FX & Risk-Free rate values along with source, tenor, date, and fetch timestamp."""
    curr = (currency or "USD").strip().upper()
    fx = get_usd_thb_rate()
    rf = get_risk_free_rate(currency=curr)
    fx_info = _fx_meta.get("usd_thb", {})
    rf_key = "THB" if curr == "THB" else "USD"
    rf_info = _rf_meta.get(rf_key, {})
    return {
        "usd_thb_rate": fx,
        "fx_date": fx_info.get("fx_date"),
        "fx_updated_at": fx_info.get("fx_updated_at") or datetime.now(timezone.utc).isoformat(),
        "is_fallback_fx": bool(_last_fx_is_fallback or fx_info.get("is_fallback_fx", False)),
        "risk_free_rate": rf,
        "risk_free_source": rf_info.get("risk_free_source", "BOT / พันธบัตรรัฐบาลไทย" if curr == "THB" else "US 13W Treasury Bill (^IRX)"),
        "risk_free_tenor": rf_info.get("risk_free_tenor", "อ้างอิงในระบบ" if curr == "THB" else "13 สัปดาห์"),
        "risk_free_date": rf_info.get("risk_free_date"),
        "rf_updated_at": rf_info.get("rf_updated_at") or datetime.now(timezone.utc).isoformat(),
        "is_fallback_rf": bool(_last_rf_is_fallback or rf_info.get("is_fallback_rf", False)),
    }


def _infer_effective_trading_days(prices: pd.DataFrame) -> int:
    """Infer effective trading days per year from actual price index (365 for 24/7 crypto, 252 for equities)."""
    if isinstance(prices.index, pd.DatetimeIndex) and len(prices.index) >= 20:
        cal_days = float((prices.index[-1] - prices.index[0]).days)
        if cal_days >= 30.0:
            years = cal_days / 365.25
            obs_per_year = (len(prices) - 1) / years
            if obs_per_year >= 310:
                return 365
            return TRADING_DAYS
    all_crypto = all(str(c).upper().endswith("-USD") for c in prices.columns)
    return 365 if all_crypto else TRADING_DAYS


def convert_prices_to_base_currency(
    prices: pd.DataFrame,
    base_currency: str = "THB",
    fx_series: Optional[pd.Series] = None,
    fallback_fx_rate: float = 34.50
) -> pd.DataFrame:
    """
    Convert historical asset price series into a single consistent base currency (THB or USD)
    using daily historical FX rates (THB=X) before computing returns, covariance, or backtests.
    """
    target_curr = (base_currency or "THB").strip().upper()
    cols = list(prices.columns)
    needs_fx = any(get_ticker_currency(t) != target_curr for t in cols)
    if not needs_fx:
        return prices.copy()

    if fx_series is None and isinstance(prices.index, pd.DatetimeIndex) and len(prices.index) >= 2:
        s_str = prices.index[0].strftime("%Y-%m-%d")
        e_str = (prices.index[-1] + pd.Timedelta(days=2)).strftime("%Y-%m-%d")
        fx_cache_key = (("THB=X",), s_str, e_str)
        now = time.time()
        if fx_cache_key in _price_cache and (now - _price_cache[fx_cache_key][0] < PRICE_CACHE_TTL):
            fx_series = _price_cache[fx_cache_key][1]["THB=X"]
        else:
            try:
                with _yf_lock:
                    raw_fx = yf.download("THB=X", start=s_str, end=e_str, auto_adjust=True, progress=False)
                if not raw_fx.empty:
                    fx_col = raw_fx["Close"] if "Close" in raw_fx.columns else raw_fx
                    if isinstance(fx_col, pd.DataFrame):
                        fx_col = fx_col.iloc[:, 0]
                    fx_clean = fx_col.dropna()
                    if not fx_clean.empty:
                        fx_series = fx_clean
                        _price_cache[fx_cache_key] = (now, pd.DataFrame({"THB=X": fx_clean}), ["THB=X"], [])
            except Exception:
                fx_series = None

    fx_history_fallback = False
    if fx_series is not None and not fx_series.empty:
        aligned_fx = fx_series.reindex(prices.index).ffill().bfill()
        aligned_fx = aligned_fx.fillna(fallback_fx_rate)
    else:
        fx_history_fallback = True
        aligned_fx = pd.Series(float(fallback_fx_rate), index=prices.index)

    converted = prices.copy().astype(float)
    for t in cols:
        native_curr = get_ticker_currency(t)
        if native_curr == "USD" and target_curr == "THB":
            converted[t] = converted[t] * aligned_fx
        elif native_curr == "THB" and target_curr == "USD":
            converted[t] = converted[t] / aligned_fx.replace(0.0, np.nan).ffill().fillna(fallback_fx_rate)
    converted.attrs["fx_history_fallback"] = fx_history_fallback
    return converted


def fetch_historical_prices(
    tickers: List[str],
    start_date: str,
    end_date: str
) -> Tuple[pd.DataFrame, List[str], List[str]]:
    """
    Download adjusted close prices for tickers between start_date and end_date.
    Thread-safe and cached for multi-user performance.
    """
    clean_tickers = []
    for t in tickers:
        s = t.strip().upper()
        if s and s not in clean_tickers:
            clean_tickers.append(s)

    if not clean_tickers:
        raise ValueError("กรุณาเลือกสินทรัพย์อย่างน้อย 2 รายการ")

    cache_key = (tuple(clean_tickers), start_date, end_date)
    now = time.time()
    if cache_key in _price_cache:
        ts, cached_df, cached_valid, cached_missing = _price_cache[cache_key]
        if now - ts < PRICE_CACHE_TTL:
            return cached_df.copy(), list(cached_valid), list(cached_missing)

    try:
        with _yf_lock:
            raw = yf.download(
                clean_tickers,
                start=start_date,
                end=end_date,
                auto_adjust=True,
                progress=False
            )
    except Exception as e:
        err_msg = str(e)
        if "429" in err_msg or "rate" in err_msg.lower() or "too many" in err_msg.lower():
            raise ValueError("ระบบดึงข้อมูลราคาติดข้อจำกัดความถี่ (Rate Limit) จาก Yahoo Finance กรุณารอสักครู่แล้วลองใหม่อีกครั้ง")
        raise ValueError(f"ไม่สามารถเชื่อมต่อ Yahoo Finance ได้ในขณะนี้ ({err_msg})")

    if raw.empty:
        raise ValueError(
            f"ไม่สามารถดึงข้อมูลราคาของ {clean_tickers} ในช่วงเวลา {start_date} ถึง {end_date} "
            f"(อาจเกิดจากชื่อย่อหุ้นไม่ถูกต้อง หรือ Yahoo Finance จำกัดการเรียกข้อมูลชั่วคราว)"
        )

    if 'Close' in raw.columns:
        close_df = raw['Close']
    else:
        close_df = raw

    if isinstance(close_df, pd.Series):
        close_df = close_df.to_frame(name=clean_tickers[0])

    valid_tickers = []
    missing_tickers = []

    for t in clean_tickers:
        if t in close_df.columns and not close_df[t].dropna().empty:
            valid_tickers.append(t)
        else:
            missing_tickers.append(t)

    if len(valid_tickers) < 2:
        raise ValueError(
            f"ต้องมีสินทรัพย์ที่มีข้อมูลราคาสมบูรณ์อย่างน้อย 2 รายการขึ้นไป "
            f"(พบข้อมูล: {valid_tickers}, ไม่พบข้อมูล: {missing_tickers})"
        )

    # Align calendars across markets (e.g. SET .BK holidays vs US holidays vs 24/7 Crypto):
    # Trim leading NaNs before all assets started trading, then forward-fill holiday gaps up to 5 days
    sub_df = close_df[valid_tickers].copy()
    raw_last_dates: Dict[str, str] = {}
    for t in valid_tickers:
        last_idx = sub_df[t].last_valid_index()
        if last_idx is not None:
            raw_last_dates[t] = last_idx.strftime('%Y-%m-%d') if hasattr(last_idx, 'strftime') else str(last_idx)

    first_valid_dates = [sub_df[t].first_valid_index() for t in valid_tickers if sub_df[t].first_valid_index() is not None]
    if first_valid_dates:
        common_start = max(first_valid_dates)
        sub_df = sub_df.loc[common_start:]
    prices = sub_df.ffill(limit=5).dropna()

    if len(prices) < 20:
        raise ValueError(f"จำนวนวันทำการที่ข้อมูลทับซ้อนกันน้อยเกินไป ({len(prices)} วัน) กรุณาขยายช่วงเวลาให้กว้างขึ้น")

    prices.attrs["raw_last_dates"] = raw_last_dates
    # Save to cache (limit cache size to 100 entries)
    if len(_price_cache) > 100:
        _price_cache.clear()
    _price_cache[cache_key] = (now, prices.copy(), list(valid_tickers), list(missing_tickers))

    return prices, valid_tickers, missing_tickers


def compute_max_drawdown(wealth_series: pd.Series) -> float:
    """Compute maximum percentage drawdown from peak."""
    running_max = wealth_series.cummax()
    drawdown = (wealth_series - running_max) / running_max
    return float(drawdown.min())


def compute_drawdown_details(cum_growth: pd.Series, budget: float) -> Dict[str, Any]:
    """
    Compute comprehensive drawdown analytics:
    - max_drawdown_pct: worst peak-to-trough percentage drop
    - peak_to_trough_amount / max_drawdown_amount: actual monetary drop from historical peak_wealth to trough_wealth
    - min_capital_remaining / trough_value: actual portfolio value at the trough of the worst drawdown
    - min_portfolio_value: lowest portfolio value ever reached since day 1
    - initial_budget_scaled_loss: equivalent loss if `budget` were invested right at the peak
    """
    if cum_growth.empty:
        return {
            "max_drawdown_pct": 0.0,
            "max_drawdown_amount": 0.0,
            "min_capital_remaining": round(budget, 2),
            "min_portfolio_value": round(budget, 2),
            "initial_budget_scaled_loss": 0.0,
            "peak_to_trough_amount": 0.0,
            "peak_value": round(budget, 2),
            "trough_value": round(budget, 2),
            "peak_date": "-",
            "trough_date": "-",
            "recovery_date": None,
            "recovery_days": None
        }

    # Include starting point = 1.0 so drawdowns from initial capital on day 1 are captured accurately
    running_max = cum_growth.cummax().clip(lower=1.0)
    dd_series = (cum_growth - running_max) / running_max
    mdd_pct = float(dd_series.min())

    # Historical Peak, Trough, and Recovery Dates
    trough_idx = dd_series.idxmin()
    peak_slice = cum_growth.loc[:trough_idx]
    peak_idx = peak_slice.idxmax() if not peak_slice.empty else trough_idx

    peak_level = max(1.0, float(cum_growth.loc[peak_idx]))
    trough_level = float(cum_growth.loc[trough_idx])

    peak_wealth = round(peak_level * budget, 2)
    trough_wealth = round(trough_level * budget, 2)
    peak_to_trough_loss = round(max(0.0, peak_wealth - trough_wealth), 2)
    initial_budget_scaled_loss = round(abs(mdd_pct) * budget, 2)
    min_portfolio_value = round(min(float(budget), float(cum_growth.min()) * budget), 2)

    after_trough = cum_growth.loc[trough_idx:]
    recovered = after_trough[after_trough >= peak_level]
    if not recovered.empty and trough_level < peak_level:
        rec_idx = recovered.index[0]
        recovery_date = rec_idx.strftime('%Y-%m-%d') if hasattr(rec_idx, 'strftime') else str(rec_idx)
        recovery_days = int((rec_idx - peak_idx).days) if hasattr(rec_idx - peak_idx, 'days') else None
    else:
        recovery_date = None
        recovery_days = None

    return {
        "max_drawdown_pct": round(mdd_pct, 4),
        "max_drawdown_amount": peak_to_trough_loss,
        "min_capital_remaining": trough_wealth,
        "min_portfolio_value": min_portfolio_value,
        "initial_budget_scaled_loss": initial_budget_scaled_loss,
        "peak_to_trough_amount": peak_to_trough_loss,
        "peak_value": peak_wealth,
        "trough_value": trough_wealth,
        "peak_date": peak_idx.strftime('%Y-%m-%d') if hasattr(peak_idx, 'strftime') else str(peak_idx),
        "trough_date": trough_idx.strftime('%Y-%m-%d') if hasattr(trough_idx, 'strftime') else str(trough_idx),
        "recovery_date": recovery_date,
        "recovery_days": recovery_days
    }


def compute_discrete_allocation(
    weights: Dict[str, float],
    latest_prices: pd.Series,
    budget: float,
    budget_currency: str = "THB",
    usd_thb_rate: float = 34.50
) -> Dict[str, Any]:
    """
    Calculate integer share quantities, fractional shares, and leftover cash.
    Automatically converts asset prices to the user's budget currency (default THB)
    so Baht amounts and share quantities are 100% consistent and accurate.
    """
    try:
        active_weights = {k: v for k, v in weights.items() if v > 0.0001}
        if not active_weights:
            return {"shares": {}, "leftover": budget, "cash_spent": 0, "allocated_percent": 0, "allocations": []}

        # Convert prices into budget_currency for accurate share count calculation
        converted_prices_dict = {}
        for ticker in active_weights.keys():
            raw_p = float(latest_prices[ticker])
            native_curr = get_ticker_currency(ticker)
            if budget_currency.upper() == "THB" and native_curr == "USD":
                converted_prices_dict[ticker] = round(raw_p * usd_thb_rate, 4)
            elif budget_currency.upper() == "USD" and native_curr == "THB":
                converted_prices_dict[ticker] = round(raw_p / usd_thb_rate, 4) if usd_thb_rate > 0 else raw_p
            else:
                converted_prices_dict[ticker] = raw_p

        sub_prices = pd.Series(converted_prices_dict)
        da = DiscreteAllocation(active_weights, sub_prices, total_portfolio_value=budget)
        shares, leftover = da.greedy_portfolio()

        allocations = []
        total_spent = 0.0
        sorted_keys = sorted(active_weights.keys(), key=lambda x: active_weights[x], reverse=True)

        for ticker in sorted_keys:
            n_shares = int(shares.get(ticker, 0))
            price_in_budget_curr = float(sub_prices[ticker])
            raw_native_price = float(latest_prices[ticker])
            native_curr = get_ticker_currency(ticker)
            price_thb = round(raw_native_price * usd_thb_rate, 2) if native_curr == "USD" else round(raw_native_price, 2)
            price_usd = round(raw_native_price, 2) if native_curr == "USD" else (round(raw_native_price / usd_thb_rate, 2) if usd_thb_rate > 0 else round(raw_native_price, 2))

            target_amount = budget * float(active_weights[ticker])
            fractional = round(target_amount / price_in_budget_curr, 4) if price_in_budget_curr > 0 else 0.0
            val = n_shares * price_in_budget_curr
            total_spent += val
            allocations.append({
                "ticker": ticker,
                "name": get_asset_name(ticker),
                "native_currency": native_curr,
                "native_price": round(raw_native_price, 2),
                "price_thb": price_thb,
                "price_usd": price_usd,
                "current_price": round(price_in_budget_curr, 2),
                "target_weight": round(float(active_weights[ticker]), 4),
                "target_value": round(target_amount, 2),
                "shares": n_shares,
                "fractional_shares": fractional,
                "allocated_value": round(val, 2),
                "actual_weight": round(val / budget, 4) if budget > 0 else 0
            })

        return {
            "shares": {k: int(v) for k, v in shares.items()},
            "leftover": round(float(leftover), 2),
            "cash_spent": round(total_spent, 2),
            "allocated_percent": round((total_spent / budget) * 100, 2) if budget > 0 else 0,
            "allocations": allocations
        }
    except Exception as e:
        print(f"Error in discrete allocation: {e}")
        return {"shares": {}, "leftover": budget, "cash_spent": 0, "allocated_percent": 0, "allocations": []}


POSITIVE_NEWS_PHRASES = [
    "rate cut", "rate cuts", "cuts rates", "cut rates", "cutting rates",
    "price target raised", "raises price target", "raised price target",
    "beats expectations", "beat expectations", "better than expected",
    "record high", "all-time high", "strong buy", "share buyback",
    "dividend hike", "earnings beat", "revenue beat", "lifts guidance", "raises guidance",
    "ลดดอกเบี้ย", "ปรับเป้าขึ้น", "กำไรโตเกินคาด", "ทำจุดสูงสุดใหม่", "ซื้อหุ้นคืน"
]

NEGATIVE_NEWS_PHRASES = [
    "rate hike", "rate hikes", "raises rates", "raise rates", "hiking rates",
    "high risk", "not a buy", "no longer a buy", "no growth", "not bullish",
    "misses expectations", "miss expectations", "worse than expected",
    "price target cut", "cuts price target", "cut price target",
    "downgraded to sell", "profit warning", "earnings miss", "revenue miss",
    "cuts guidance", "lowers guidance", "below expectations",
    "ขึ้นดอกเบี้ย", "ไม่แนะนำซื้อ", "หั่นเป้าราคา", "ความเสี่ยงสูง", "กำไรต่ำคาด", "ขาดทุนหนัก"
]

POSITIVE_NEWS_KEYWORDS = [
    "beat", "beats", "surge", "surges", "soar", "soars", "record", "upgrade", "upgraded",
    "bullish", "outperform", "growth", "profit", "gain", "gains", "rally", "rallies",
    "buy", "strong", "optimism", "breakthrough", "partnership", "dividend", "buyback",
    "demand", "accumulate", "upside", "positive", "jump", "jumps", "high", "boom",
    "กำไรพุ่ง", "นิวไฮ", "เติบโต", "โดดเด่น", "ปันผล", "แนะซื้อ", "บวก", "ขาขึ้น", "ทะยาน",
    "แข็งแกร่ง", "หนุน", "ฟื้นตัว", "สดใส", "เป้าใหม่", "สูงสุด"
]

NEGATIVE_NEWS_KEYWORDS = [
    "miss", "misses", "plunge", "plunges", "drop", "drops", "fall", "falls", "downgrade",
    "downgraded", "bearish", "underperform", "loss", "decline", "declines", "lawsuit",
    "probe", "investigation", "recall", "delay", "warning", "cut", "cuts", "tariff",
    "layoff", "layoffs", "weak", "risk", "sell", "slump", "crash", "concern", "headwind",
    "ขาดทุน", "ร่วง", "ดิ่ง", "ลดเป้า", "กังวล", "กดดัน", "ชะลอตัว", "เสี่ยง", "หั่นเป้า", "ลบ", "ขาลง", "ผันผวน"
]

_EN_NEGATION_TOKENS = {
    "not", "no", "never", "without", "hardly", "unlikely", "avoid",
    "fails", "failed", "failing", "dont", "don't", "doesnt", "doesn't",
    "isnt", "isn't", "arent", "aren't", "wont", "won't", "cant", "can't"
}


def analyze_headline_sentiment(title: str) -> Tuple[str, float, str]:
    """
    Analyze financial news headline sentiment (English & Thai) with phrase-first
    financial idioms, English word-boundary matching, and negation window handling.
    Returns (sentiment_type, score_in_[-1,1], thai_label).
    """
    lower_t = (title or "").lower()
    working = lower_t
    pos_hits = 0
    neg_hits = 0

    # 1. Phrase-first matching (prevents idioms like "rate cut", "not a buy", "high risk" from mis-scoring)
    for phrase in sorted(NEGATIVE_NEWS_PHRASES, key=len, reverse=True):
        if phrase.isascii():
            pat = r"\b" + re.escape(phrase) + r"\b"
            matches = re.findall(pat, working)
            if matches:
                neg_hits += len(matches)
                working = re.sub(pat, " ", working)
        elif phrase in working:
            neg_hits += working.count(phrase)
            working = working.replace(phrase, " ")

    for phrase in sorted(POSITIVE_NEWS_PHRASES, key=len, reverse=True):
        if phrase.isascii():
            pat = r"\b" + re.escape(phrase) + r"\b"
            matches = re.findall(pat, working)
            if matches:
                pos_hits += len(matches)
                working = re.sub(pat, " ", working)
        elif phrase in working:
            pos_hits += working.count(phrase)
            working = working.replace(phrase, " ")

    # 2. Single-keyword matching with word boundaries (ASCII) and clause-bounded negation window
    _CLAUSE_BREAK_TOKENS = {"but", "however", "while", "whereas", "although", "yet"}

    def _has_en_negation_before(text: str, start_idx: int) -> bool:
        raw_prefix = text[max(0, start_idx - 32):start_idx]
        # Truncate at the most recent punctuation clause separator (, . ; : ! ? - |)
        clause_tail = re.split(r"[,.;:!?|—\-]+", raw_prefix)[-1]
        tokens = re.findall(r"[a-z']+", clause_tail)
        # Also truncate after contrastive conjunctions ("but", "however", "while")
        for idx_tok in range(len(tokens) - 1, -1, -1):
            if tokens[idx_tok] in _CLAUSE_BREAK_TOKENS:
                tokens = tokens[idx_tok + 1:]
                break
        recent_tokens = tokens[-3:]
        return any(tok in _EN_NEGATION_TOKENS for tok in recent_tokens)

    def _has_th_negation_before(text: str, start_idx: int, neg_words: Tuple[str, ...]) -> bool:
        raw_prefix = text[max(0, start_idx - 10):start_idx]
        clause_tail = re.split(r"[,.;:!?|—\-\s]+", raw_prefix)[-1]
        for conj in ("และ", "พร้อม", "แต่", "ทว่า", "แม้", "ส่วน", "ขณะที่"):
            if conj in clause_tail:
                clause_tail = clause_tail.split(conj)[-1]
        # In Thai, negation immediately precedes the verb/adjective (or with 'ได้'/'ค่อย'/'เคย')
        near_tail = clause_tail[-5:]
        return any(neg_th in near_tail for neg_th in neg_words)

    for kw in POSITIVE_NEWS_KEYWORDS:
        if kw.isascii():
            for m in re.finditer(r"\b" + re.escape(kw) + r"\b", working):
                if _has_en_negation_before(working, m.start()):
                    neg_hits += 1
                else:
                    pos_hits += 1
        else:
            for m in re.finditer(re.escape(kw), working):
                if _has_th_negation_before(working, m.start(), ("ไม่", "ไร้", "มิใช่")):
                    neg_hits += 1
                else:
                    pos_hits += 1

    for kw in NEGATIVE_NEWS_KEYWORDS:
        if kw.isascii():
            for m in re.finditer(r"\b" + re.escape(kw) + r"\b", working):
                if not _has_en_negation_before(working, m.start()):
                    neg_hits += 1
        else:
            for m in re.finditer(re.escape(kw), working):
                if not _has_th_negation_before(working, m.start(), ("ไม่", "ไร้", "พ้น")):
                    neg_hits += 1

    if pos_hits > neg_hits:
        score = min(1.0, 0.45 + 0.25 * (pos_hits - neg_hits))
        return "positive", round(score, 2), "ข่าวหนุนเชิงบวก"
    elif neg_hits > pos_hits:
        score = -min(1.0, 0.45 + 0.25 * (neg_hits - pos_hits))
        return "negative", round(score, 2), "ข่าวกดดัน/ควรระวัง"
    return "neutral", 0.0, "ข่าวติดตามสภาวะตลาด"


def fetch_market_news_for_ticker(ticker: str, max_items: int = 4, force_refresh: bool = False) -> Dict[str, Any]:
    """
    Fetch live market news for a ticker from Yahoo Finance Search API and Google News RSS.
    Thread-safe, deduplicated by normalized title, and cached for 10 minutes unless force_refresh=True.
    """
    clean_t = ticker.strip().upper()
    now = time.time()
    if not force_refresh:
        with _news_cache_lock:
            if clean_t in _news_cache:
                ts, cached_val = _news_cache[clean_t]
                if now - ts < NEWS_CACHE_TTL:
                    return cached_val

    articles: List[Dict[str, Any]] = []
    seen_titles: set = set()
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    }

    def _norm_title_key(raw: str) -> str:
        return re.sub(r"\s+", " ", (raw or "").strip().lower())

    # 1. Try Yahoo Finance Search News first for non-.BK tickers
    if not clean_t.endswith(".BK"):
        try:
            yf_url = f"https://query2.finance.yahoo.com/v1/finance/search?q={requests.utils.quote(clean_t)}&quotesCount=1&newsCount=6"
            res = requests.get(yf_url, headers=headers, timeout=3.5)
            if res.status_code == 200:
                raw_news = res.json().get("news", [])
                for item in raw_news:
                    title = (item.get("title") or "").strip()
                    norm_key = _norm_title_key(title)
                    if not title or norm_key in seen_titles:
                        continue
                    seen_titles.add(norm_key)
                    pub_ts = item.get("providerPublishTime")
                    pub_str = (
                        datetime.fromtimestamp(pub_ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
                        if pub_ts else "ล่าสุด"
                    )
                    sent_type, sent_score, sent_label = analyze_headline_sentiment(title)
                    articles.append({
                        "ticker": clean_t,
                        "title": title,
                        "publisher": item.get("publisher") or "Yahoo Finance",
                        "link": item.get("link") or f"https://finance.yahoo.com/quote/{clean_t}",
                        "published_at": pub_str,
                        "sentiment": sent_type,
                        "sentiment_score": sent_score,
                        "sentiment_label_th": sent_label
                    })
                    if len(articles) >= max_items:
                        break
        except Exception:
            pass

    # 2. Fallback / Supplement via Google News Financial RSS (supports both Thai .BK and Global stocks)
    if len(articles) < 2:
        try:
            is_thai = clean_t.endswith(".BK")
            base_sym = clean_t.replace(".BK", "")
            query_str = f"{base_sym} หุ้น" if is_thai else f"{clean_t} stock market"
            hl_param = "th&gl=TH&ceid=TH:th" if is_thai else "en-US&gl=US&ceid=US:en"
            rss_url = f"https://news.google.com/rss/search?q={requests.utils.quote(query_str)}&hl={hl_param}"
            res = requests.get(rss_url, headers=headers, timeout=3.5)
            if res.status_code == 200:
                root = ET.fromstring(res.content)
                for item in root.findall(".//item"):
                    raw_title = (item.findtext("title") or "").strip()
                    if not raw_title:
                        continue
                    source_el = item.find("source")
                    publisher = source_el.text.strip() if (source_el is not None and source_el.text) else "Google Finance News"
                    if " - " in raw_title and raw_title.endswith(publisher):
                        raw_title = raw_title[: -len(publisher) - 3].strip()
                    norm_key = _norm_title_key(raw_title)
                    if not raw_title or norm_key in seen_titles:
                        continue
                    seen_titles.add(norm_key)
                    link = (item.findtext("link") or f"https://finance.yahoo.com/quote/{clean_t}").strip()
                    pub_date = (item.findtext("pubDate") or "")[:16].strip() or "ล่าสุด"
                    sent_type, sent_score, sent_label = analyze_headline_sentiment(raw_title)
                    articles.append({
                        "ticker": clean_t,
                        "title": raw_title,
                        "publisher": publisher,
                        "link": link,
                        "published_at": pub_date,
                        "sentiment": sent_type,
                        "sentiment_score": sent_score,
                        "sentiment_label_th": sent_label
                    })
                    if len(articles) >= max_items:
                        break
        except Exception:
            pass

    pos_cnt = sum(1 for a in articles if a["sentiment"] == "positive")
    neg_cnt = sum(1 for a in articles if a["sentiment"] == "negative")
    neu_cnt = sum(1 for a in articles if a["sentiment"] == "neutral")

    if articles:
        avg_score = sum(float(a["sentiment_score"]) for a in articles) / len(articles)
    else:
        avg_score = 0.0

    result = {
        "ticker": clean_t,
        "name": get_asset_name(clean_t),
        "news_sentiment_score": round(float(np.clip(avg_score, -1.0, 1.0)), 3),
        "positive_count": pos_cnt,
        "negative_count": neg_cnt,
        "neutral_count": neu_cnt,
        "articles": articles[:max_items]
    }
    with _news_cache_lock:
        if len(_news_cache) > 200:
            _news_cache.clear()
        _news_cache[clean_t] = (now, result)
    return result


def fetch_portfolio_market_news(tickers: List[str], force_refresh: bool = False) -> Dict[str, Dict[str, Any]]:
    """Fetch market news concurrently for all tickers in portfolio."""
    from concurrent.futures import ThreadPoolExecutor
    results: Dict[str, Dict[str, Any]] = {}
    clean_list = [t.strip().upper() for t in tickers if t.strip()]
    if not clean_list:
        return results

    with ThreadPoolExecutor(max_workers=min(6, len(clean_list))) as executor:
        future_map = {executor.submit(fetch_market_news_for_ticker, t, 4, force_refresh): t for t in clean_list}
        for fut, t in future_map.items():
            try:
                results[t] = fut.result(timeout=4.5)
            except Exception:
                results[t] = {
                    "ticker": t,
                    "name": get_asset_name(t),
                    "news_sentiment_score": 0.0,
                    "positive_count": 0,
                    "negative_count": 0,
                    "neutral_count": 0,
                    "articles": []
                }
    return results


def compute_technical_signals(price_series: pd.Series) -> Dict[str, Any]:
    """
    Compute credible technical indicators from historical close prices:
    - 14-day RSI
    - 50-day & 200-day Simple Moving Averages (SMA)
    - 1-Month (21d) & 3-Month (63d) price momentum
    """
    s = price_series.dropna()
    if len(s) < 15:
        return {
            "rsi_14": 50.0,
            "sma_50": float(s.iloc[-1]) if len(s) else 0.0,
            "sma_200": float(s.iloc[-1]) if len(s) else 0.0,
            "price_vs_sma50_pct": 0.0,
            "price_vs_sma200_pct": 0.0,
            "momentum_1m": 0.0,
            "momentum_3m": 0.0,
            "trend_status": "CONSOLIDATION",
            "trend_label_th": "แกว่งตัวสะสมกำลัง",
            "rsi_status_th": "ระดับสมดุลปกติ",
            "technical_score": 0.0
        }

    latest = float(s.iloc[-1])
    delta = s.diff()
    gain = delta.clip(lower=0.0)
    loss = -delta.clip(upper=0.0)
    avg_gain = gain.rolling(window=14, min_periods=14).mean().iloc[-1]
    avg_loss = loss.rolling(window=14, min_periods=14).mean().iloc[-1]
    if avg_loss == 0:
        rsi_14 = 75.0 if avg_gain > 0 else 50.0
    else:
        rs = float(avg_gain / avg_loss)
        rsi_14 = 100.0 - (100.0 / (1.0 + rs))

    w50 = min(50, len(s))
    w200 = min(200, len(s))
    sma_50 = float(s.iloc[-w50:].mean())
    sma_200 = float(s.iloc[-w200:].mean())
    vs_50 = (latest / sma_50 - 1.0) if sma_50 > 0 else 0.0
    vs_200 = (latest / sma_200 - 1.0) if sma_200 > 0 else 0.0

    idx_1m = max(0, len(s) - 22)
    idx_3m = max(0, len(s) - 64)
    mom_1m = (latest / float(s.iloc[idx_1m]) - 1.0) if float(s.iloc[idx_1m]) > 0 else 0.0
    mom_3m = (latest / float(s.iloc[idx_3m]) - 1.0) if float(s.iloc[idx_3m]) > 0 else 0.0

    # Trend classification
    if latest >= sma_50 and sma_50 >= sma_200:
        trend_status = "UPTREND"
        trend_label_th = "ขาขึ้นแข็งแกร่ง (ราคาเหนือค่าเฉลี่ย 50 และ 200 วัน)"
        trend_score = 0.55
    elif latest >= sma_50 and sma_50 < sma_200:
        trend_status = "RECOVERY"
        trend_label_th = "ฟื้นตัวระยะสั้น (กลับมายืนเหนือเส้น 50 วัน)"
        trend_score = 0.25
    elif latest < sma_50 and latest >= sma_200:
        trend_status = "CONSOLIDATION"
        trend_label_th = "ย่อตัวพักฐานบนแนวโน้มหลัก"
        trend_score = 0.05
    else:
        trend_status = "DOWNTREND"
        trend_label_th = "ชะลอตัว (ราคาต่ำกว่าค่าเฉลี่ย 50 และ 200 วัน)"
        trend_score = -0.45

    # RSI interpretation for prudent entry
    if rsi_14 >= 72.0:
        rsi_status_th = f"RSI {rsi_14:.0f} (ซื้อมากเกินไป ระวังการไล่ราคา)"
        rsi_adj = -0.20
    elif rsi_14 <= 32.0:
        rsi_status_th = f"RSI {rsi_14:.0f} (ขายมากเกินไป โซนราคาอ่อนตัวสะสม)"
        rsi_adj = 0.20
    else:
        rsi_status_th = f"RSI {rsi_14:.0f} (ระดับสมดุลปกติ)"
        rsi_adj = 0.10 if 45.0 <= rsi_14 <= 65.0 else 0.0

    tech_score = float(np.clip(trend_score + rsi_adj, -1.0, 1.0))

    return {
        "rsi_14": round(float(rsi_14), 1),
        "sma_50": round(sma_50, 2),
        "sma_200": round(sma_200, 2),
        "price_vs_sma50_pct": round(float(vs_50), 4),
        "price_vs_sma200_pct": round(float(vs_200), 4),
        "momentum_1m": round(float(mom_1m), 4),
        "momentum_3m": round(float(mom_3m), 4),
        "trend_status": trend_status,
        "trend_label_th": trend_label_th,
        "rsi_status_th": rsi_status_th,
        "technical_score": round(tech_score, 3)
    }


def build_asset_decision_intelligence(
    ticker: str,
    raw_expected_return: float,
    volatility: float,
    tech_info: Dict[str, Any],
    news_info: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Combine historical stats, live market news sentiment, and technical trend/RSI
    into a prudent, actionable buy/hold/reduce decision recommendation and Black-Litterman return tilt.
    """
    news_score = float(news_info.get("news_sentiment_score", 0.0))
    tech_score = float(tech_info.get("technical_score", 0.0))
    rsi = float(tech_info.get("rsi_14", 50.0))
    trend = tech_info.get("trend_status", "CONSOLIDATION")

    # Composite confidence score in [-1, +1]
    composite = round(float(np.clip(0.55 * news_score + 0.45 * tech_score, -1.0, 1.0)), 3)

    # Prudent Bayesian / Black-Litterman expected return adjustment (capped at +/- 4.5% annual)
    max_tilt = min(0.045, max(0.015, 0.12 * volatility))
    return_tilt = round(float(composite * max_tilt), 4)
    adjusted_return = round(float(raw_expected_return + return_tilt), 4)

    if composite >= 0.20 and rsi < 72.0:
        signal_level = "POSITIVE_BUY"
        signal_badge_th = "สัญญาณบวกหนุนซื้อ"
        execution_tactic_th = "ทยอยซื้อเข้าพอร์ตได้ตามสัดส่วนเป้าหมาย"
        decision_reason_th = f"{tech_info['trend_label_th']} ประกอบกับกระแสข่าวตลาดอยู่ในเกณฑ์บวก ({tech_info['rsi_status_th']})"
    elif rsi >= 72.0:
        signal_level = "OVERBOUGHT_TRANCHE"
        signal_badge_th = "ราคาตึงตัว (แบ่งไม้ซื้อ)"
        execution_tactic_th = "แนะนำแบ่งเงินซื้อเป็น 2-3 ไม้ ไม่ไล่ราคาครั้งเดียว"
        decision_reason_th = f"แนวโน้มระยะยาวยังดี แต่ระยะสั้น {tech_info['rsi_status_th']} จึงควรแบ่งไม้เข้าซื้อเพื่อลดต้นทุนเฉลี่ย"
    elif composite <= -0.18 or trend == "DOWNTREND":
        signal_level = "CAUTIOUS_SHIELD"
        signal_badge_th = "ชะลอตัว/ลดเพดานเสี่ยง"
        execution_tactic_th = "ลดน้ำหนักลงบางส่วน หรือรอจังหวะราคาสร้างฐาน"
        decision_reason_th = f"{tech_info['trend_label_th']} และมีปัจจัยข่าวระยะสั้นที่ต้องเฝ้าระวัง ระบบจึงปรับลดน้ำหนักลงอย่างรอบคอบ"
    else:
        signal_level = "NEUTRAL_ACCUMULATE"
        signal_badge_th = "สมดุล/สะสมตามแผน"
        execution_tactic_th = "จัดสรรตามสัดส่วนมาตรฐานของกลยุทธ์"
        decision_reason_th = f"{tech_info['trend_label_th']} และ {tech_info['rsi_status_th']} เหมาะสำหรับการถือครองตามแผนระยะยาว"

    return {
        "ticker": ticker,
        "news_sentiment_score": news_score,
        "technical_score": tech_score,
        "composite_signal_score": composite,
        "raw_expected_return": round(raw_expected_return, 4),
        "return_tilt": return_tilt,
        "adjusted_expected_return": adjusted_return,
        "signal_level": signal_level,
        "signal_badge_th": signal_badge_th,
        "execution_tactic_th": execution_tactic_th,
        "decision_reason_th": decision_reason_th
    }


def compute_black_litterman_posterior(
    mu_hist: pd.Series,
    S_mat: pd.DataFrame,
    prior_weights: Dict[str, float],
    valid_tickers: List[str],
    rf_rate: float,
    views_delta: Optional[Dict[str, float]] = None,
    confidence: float = 0.50,
    tau: float = 0.05
) -> Dict[str, Any]:
    """
    Analytical Black-Litterman Posterior (He & Litterman 1999 + Idzorek 2005 Confidence Scaling)
    using pure NumPy linear algebra (zero heavy external dependencies).

    - Prior (Equilibrium): pi = rf + delta * Sigma * w_prior (where w_prior = HRP risk-balanced weights).
      Maximizing Sharpe on (pi, Sigma) recovers w_prior cleanly when confidence = 0 or views = 0.
    - Views: Absolute return views Q_k = pi_k + views_delta[k] for each non-zero view.
    - Uncertainty Omega (Idzorek 2005): omega_k = ((1 - c) / c) * (p_k * tau * Sigma * p_k^T).
    - Posterior via Woodbury form (avoids inverting Omega directly, safe even at confidence = 1.0):
        mu_BL    = pi + tau * Sigma * P^T * (P * tau * Sigma * P^T + Omega)^(-1) * (Q - P * pi)
        Sigma_BL = Sigma + tau * Sigma - tau * Sigma * P^T * (P * tau * Sigma * P^T + Omega)^(-1) * P * tau * Sigma
    """
    tickers = list(valid_tickers)
    n = len(tickers)
    if n == 0:
        empty_s = pd.Series(dtype=float)
        empty_df = pd.DataFrame()
        return {
            "mu_bl": empty_s,
            "Sigma_bl": empty_df,
            "pi_total": empty_s,
            "delta": 2.5,
            "tau": float(tau),
            "confidence": float(np.clip(confidence, 0.0, 1.0)),
            "applied_views": {},
            "active_view_count": 0
        }

    S_arr = S_mat.loc[tickers, tickers].values.astype(float)
    S_arr = 0.5 * (S_arr + S_arr.T)
    mu_arr = mu_hist.reindex(tickers).fillna(0.0).values.astype(float)

    w_prior = np.array([max(0.0, float(prior_weights.get(t, 1.0 / n))) for t in tickers], dtype=float)
    w_sum = float(w_prior.sum())
    w_prior = (w_prior / w_sum) if w_sum > 1e-12 else np.ones(n, dtype=float) / n

    # Risk aversion coefficient delta (clamped to realistic [1.5, 5.0], fallback 2.5)
    prior_var = float(w_prior @ S_arr @ w_prior)
    prior_excess = float(w_prior @ mu_arr) - float(rf_rate)
    if prior_var > 1e-8 and prior_excess > 0.0:
        delta = float(np.clip(prior_excess / prior_var, 1.5, 5.0))
    else:
        delta = 2.5

    # Reverse-optimized equilibrium prior returns: pi_total = rf + delta * Sigma * w_prior
    pi_excess = delta * (S_arr @ w_prior)
    pi_total = float(rf_rate) + pi_excess

    conf_val = float(np.clip(confidence, 0.0, 1.0))
    tau_val = float(np.clip(tau, 0.005, 0.5))
    tau_S = tau_val * S_arr

    # Sanitize views_delta into [-0.25, +0.25] annual return shift relative to equilibrium prior
    applied_views: Dict[str, float] = {}
    active_indices: List[int] = []
    q_vals: List[float] = []
    raw_views = views_delta or {}

    for idx, t in enumerate(tickers):
        raw_v = raw_views.get(t, 0.0)
        try:
            v_clean = float(np.clip(float(raw_v), -0.25, 0.25))
        except (TypeError, ValueError):
            v_clean = 0.0
        applied_views[t] = round(v_clean, 4)
        if abs(v_clean) > 1e-6:
            active_indices.append(idx)
            q_vals.append(float(pi_total[idx] + v_clean))

    if conf_val <= 1e-6 or not active_indices:
        mu_bl_arr = pi_total.copy()
        Sigma_bl_arr = S_arr.copy()
    else:
        k = len(active_indices)
        P = np.zeros((k, n), dtype=float)
        omega_diag = np.zeros(k, dtype=float)
        for row_idx, asset_idx in enumerate(active_indices):
            P[row_idx, asset_idx] = 1.0
            view_prior_var = float(max(tau_S[asset_idx, asset_idx], 1e-10))
            if conf_val >= 1.0 - 1e-9:
                omega_diag[row_idx] = 0.0
            else:
                omega_diag[row_idx] = ((1.0 - conf_val) / conf_val) * view_prior_var

        Q = np.array(q_vals, dtype=float)
        Omega = np.diag(omega_diag)
        M = P @ tau_S @ P.T + Omega
        M = 0.5 * (M + M.T)
        rhs = Q - (P @ pi_total)

        try:
            sol_ret = np.linalg.solve(M, rhs)
        except np.linalg.LinAlgError:
            jitter = np.eye(k, dtype=float) * 1e-8
            sol_ret = np.linalg.solve(M + jitter, rhs)

        mu_bl_arr = pi_total + (tau_S @ P.T @ sol_ret)
        # Keep empirical covariance S_arr aligned with pi_total = rf + delta * S_arr * w_prior (Idzorek 2005)
        # so confidence 0% -> 1% -> 100% is 100% continuous with zero (+2.47%) volatility step jump.
        Sigma_bl_arr = S_arr.copy()

    return {
        "mu_bl": pd.Series(mu_bl_arr, index=tickers),
        "Sigma_bl": pd.DataFrame(Sigma_bl_arr, index=tickers, columns=tickers),
        "pi_total": pd.Series(pi_total, index=tickers),
        "delta": round(delta, 3),
        "tau": round(tau_val, 4),
        "confidence": round(conf_val, 4),
        "applied_views": applied_views,
        "active_view_count": len(active_indices) if conf_val > 1e-6 else 0
    }


def _cap_and_normalize_weights(
    weights_dict: Dict[str, float],
    valid_tickers: List[str],
    low: float = 0.0,
    high: float = 1.0,
    decimals: int = 4
) -> Dict[str, float]:
    """
    Enforce [low, high] weight bounds via iterative proportional redistribution
    and round cleanly to `decimals` so weights sum to 1.0000 within [low, high].
    """
    n = len(valid_tickers)
    if n == 0:
        return {}
    lo = max(0.0, float(low))
    hi = min(1.0, max(float(high), 1.0 / n))

    w = np.array([max(0.0, float(weights_dict.get(t, 0.0))) for t in valid_tickers], dtype=float)
    w_sum = float(w.sum())
    w = (w / w_sum) if w_sum > 0 else (np.ones(n, dtype=float) / n)

    # Iterative proportional capping & water-filling onto [lo, hi]
    for _ in range(30):
        over = w > hi + 1e-9
        under = w < lo - 1e-9
        if not over.any() and not under.any() and abs(float(w.sum()) - 1.0) <= 1e-8:
            break
        w = np.clip(w, lo, hi)
        diff = 1.0 - float(w.sum())
        if abs(diff) <= 1e-9:
            break
        if diff > 0:
            free = w < hi - 1e-9
        else:
            free = w > lo + 1e-9
        if not free.any():
            break
        free_sum = float(w[free].sum())
        if free_sum > 1e-12:
            w[free] += diff * (w[free] / free_sum)
        else:
            w[free] += diff / float(free.sum())

    w = np.clip(w, lo, hi)
    s_final = float(w.sum())
    if s_final > 0:
        w = w / s_final
        w = np.clip(w, lo, hi)

    rounded = [round(float(x), decimals) for x in w]
    residual = round(1.0 - sum(rounded), decimals)
    if abs(residual) > 0:
        # Adjust the largest eligible weight that stays within [lo, hi]
        order = sorted(range(n), key=lambda idx: rounded[idx], reverse=True)
        for idx in order:
            cand = round(rounded[idx] + residual, decimals)
            if lo - 1e-9 <= cand <= hi + 1e-9:
                rounded[idx] = cand
                break

    return {valid_tickers[i]: rounded[i] for i in range(n)}


def _solve_all_strategies(
    mu_vec: pd.Series,
    S_mat: pd.DataFrame,
    returns_df: pd.DataFrame,
    valid_tickers: List[str],
    weight_bounds: Tuple[float, float],
    rf_rate: float,
    signal_scores: Optional[Dict[str, float]] = None
) -> Dict[str, Dict[str, Any]]:
    """
    Solve Max Sharpe, Min Volatility, HRP, and Equal Weight.
    Note: Min Volatility and HRP depend strictly on the risk/covariance structure
    and are NOT post-multiplied by news/technical signal scores.
    All 4 strategies strictly respect `weight_bounds = (min_weight, max_weight)`
    and compute return/volatility/Sharpe from the cleaned, normalized weights.
    """
    low_b, high_b = float(weight_bounds[0]), float(weight_bounds[1])

    # 1. Min Volatility (Pure minimum variance portfolio)
    ef_min = EfficientFrontier(mu_vec, S_mat, weight_bounds=weight_bounds)
    ef_min.min_volatility()
    w_min = _cap_and_normalize_weights(ef_min.clean_weights(), valid_tickers, low_b, high_b)
    w_min_s = pd.Series(w_min).reindex(valid_tickers).fillna(0.0)
    ret_min = float(w_min_s @ mu_vec)
    vol_min = float(np.sqrt(max(1e-12, w_min_s @ S_mat @ w_min_s)))
    sr_min = (ret_min - rf_rate) / vol_min if vol_min > 0 else 0.0

    # 2. Max Sharpe (Performance computed from cleaned & normalized weights)
    max_sharpe_error = None
    try:
        ef_max = EfficientFrontier(mu_vec, S_mat, weight_bounds=weight_bounds)
        ef_max.max_sharpe(risk_free_rate=rf_rate)
        w_max = _cap_and_normalize_weights(ef_max.clean_weights(), valid_tickers, low_b, high_b)
        w_max_s = pd.Series(w_max).reindex(valid_tickers).fillna(0.0)
        ret_max = float(w_max_s @ mu_vec)
        vol_max = float(np.sqrt(max(1e-12, w_max_s @ S_mat @ w_max_s)))
        sr_max = (ret_max - rf_rate) / vol_max if vol_max > 0 else 0.0
    except Exception as e:
        max_sharpe_error = str(e)
        w_max = dict(w_min)
        ret_max, vol_max, sr_max = ret_min, vol_min, sr_min

    # 3. Equal Weight (1/N)
    w_eq_raw = {t: 1.0 / len(valid_tickers) for t in valid_tickers}
    w_eq = _cap_and_normalize_weights(w_eq_raw, valid_tickers, low_b, high_b)
    w_eq_s = pd.Series(w_eq).reindex(valid_tickers).fillna(0.0)
    ret_eq = float(w_eq_s @ mu_vec)
    vol_eq = float(np.sqrt(max(1e-12, w_eq_s @ S_mat @ w_eq_s)))
    sr_eq = (ret_eq - rf_rate) / vol_eq if vol_eq > 0 else 0.0

    # 4. HRP (Pure Hierarchical Risk Parity respecting user's weight_bounds ceiling)
    hrp = HRPOpt(returns_df)
    w_hrp_raw = hrp.optimize()
    w_hrp = _cap_and_normalize_weights(w_hrp_raw, valid_tickers, low_b, high_b)
    w_hrp_s = pd.Series(w_hrp).reindex(valid_tickers).fillna(0.0)
    ret_hrp = float(w_hrp_s @ mu_vec)
    vol_hrp = float(np.sqrt(max(1e-12, w_hrp_s @ S_mat @ w_hrp_s)))
    sr_hrp = (ret_hrp - rf_rate) / vol_hrp if vol_hrp > 0 else 0.0

    return {
        "max_sharpe": {"weights": w_max, "ret": ret_max, "vol": vol_max, "sr": sr_max, "error": max_sharpe_error},
        "min_volatility": {"weights": w_min, "ret": ret_min, "vol": vol_min, "sr": sr_min, "error": None},
        "hrp": {"weights": w_hrp, "ret": ret_hrp, "vol": vol_hrp, "sr": sr_hrp, "error": None},
        "equal_weight": {"weights": w_eq, "ret": ret_eq, "vol": vol_eq, "sr": sr_eq, "error": None}
    }


def simulate_drifting_backtest_with_fees(
    returns_df: pd.DataFrame,
    target_weights: pd.Series,
    rebalance_every: int = 63,
    fee_bps: float = 15.0
) -> pd.Series:
    """
    Simulate realistic portfolio cumulative growth (starting at 1.0) with:
    - Drifting asset weights between rebalance dates
    - Periodic rebalancing every `rebalance_every` trading days (63 days = quarterly; 0 = Buy & Hold)
    - Transaction fee deduction (`fee_bps` basis points, e.g. 15 bps = 0.15%) on entry and turnover
    """
    if returns_df.empty:
        return pd.Series(dtype=float)

    fee_rate = max(0.0, float(fee_bps)) / 10000.0
    w_target = target_weights.reindex(returns_df.columns).fillna(0.0).values.astype(float)
    w_sum = w_target.sum()
    if w_sum > 0:
        w_target = w_target / w_sum

    ret_mat = returns_df.values
    n_days = len(ret_mat)
    cum_values = np.zeros(n_days, dtype=float)

    # Deduct initial entry fee
    wealth = 1.0 * (1.0 - fee_rate * w_target.sum())
    curr_w = w_target.copy()

    for d in range(n_days):
        if rebalance_every > 0 and d > 0 and (d % rebalance_every == 0):
            turnover = 0.5 * float(np.sum(np.abs(w_target - curr_w)))
            wealth *= max(0.0, 1.0 - turnover * fee_rate)
            curr_w = w_target.copy()

        asset_growth = curr_w * (1.0 + ret_mat[d])
        day_factor = float(asset_growth.sum())
        wealth *= day_factor
        if day_factor > 1e-12:
            curr_w = asset_growth / day_factor
        cum_values[d] = wealth

    return pd.Series(cum_values, index=returns_df.index)


def compute_walk_forward_backtest(
    prices_base: pd.DataFrame,
    valid_tickers: List[str],
    weight_bounds: Tuple[float, float],
    rf_rate: float,
    effective_freq: int,
    backtest_split: Optional[str] = None,
    rebalance_every: int = 63,
    fee_bps: float = 15.0
) -> Dict[str, pd.Series]:
    """
    Strict Out-of-Sample Walk-Forward Backtest (zero look-ahead bias):
    At each rebalance point t, weights are optimized using ONLY historical prices up to t
    (and never using today's live news sentiment), then held out-of-sample over [t, t + rebalance_every).
    """
    returns_df = prices_base[valid_tickers].pct_change().dropna()
    n_total = len(returns_df)
    if n_total < 30:
        w_eq = pd.Series(1.0 / len(valid_tickers), index=valid_tickers)
        eq_curve = simulate_drifting_backtest_with_fees(returns_df, w_eq, rebalance_every, fee_bps)
        return {k: eq_curve for k in ("max_sharpe", "min_volatility", "hrp", "equal_weight")}

    wf_cache_key = (
        tuple(valid_tickers),
        str(prices_base.index[0]),
        str(prices_base.index[-1]),
        int(len(prices_base)),
        round(float(prices_base[valid_tickers].iloc[0].sum()), 6),
        round(float(prices_base[valid_tickers].iloc[-1].sum()), 6),
        (round(float(weight_bounds[0]), 6), round(float(weight_bounds[1]), 6)),
        round(float(rf_rate), 6),
        int(effective_freq),
        str(backtest_split or ""),
        int(rebalance_every),
        round(float(fee_bps), 4),
    )
    now_ts = time.time()
    with _compute_cache_lock:
        cached_wf = _wf_cache.get(wf_cache_key)
        if cached_wf is not None and (now_ts - cached_wf[0] < COMPUTE_CACHE_TTL):
            return {k: s.copy() for k, s in cached_wf[1].items()}

    # Determine initial training window end index
    min_train = min(max(30, n_total // 3), max(20, n_total - 5))
    split_idx = min_train
    if backtest_split:
        try:
            split_dt = pd.to_datetime(backtest_split)
            after_mask = returns_df.index >= split_dt
            if after_mask.any():
                candidate_idx = int(np.argmax(after_mask))
                if 20 <= candidate_idx < n_total - 2:
                    split_idx = candidate_idx
        except Exception:
            pass

    fee_rate = max(0.0, float(fee_bps)) / 10000.0
    step = max(21, int(rebalance_every)) if rebalance_every > 0 else (n_total - split_idx)
    strat_keys = ("max_sharpe", "min_volatility", "hrp", "equal_weight")

    # Initialize with equal weights during the initial warm-up window (zero look-ahead)
    ret_mat = returns_df[valid_tickers].values
    n_assets = len(valid_tickers)
    w_equal_warmup = np.ones(n_assets, dtype=float) / max(1, n_assets)
    curr_w_dict = {}
    wealth_dict = {}
    cum_arr_dict = {}

    for k in strat_keys:
        curr_w_dict[k] = w_equal_warmup.copy()
        wealth_dict[k] = 1.0 * (1.0 - fee_rate)
        cum_arr_dict[k] = np.ones(n_total, dtype=float)

    # Solve all 4 strategies together once per rebalance date (avoids redundant 4x re-solving)
    for d in range(n_total):
        if d >= split_idx and ((d - split_idx) % step == 0):
            train_prices = prices_base[valid_tickers].iloc[: d + 1]
            train_rets = returns_df[valid_tickers].iloc[:d]
            mu_t = expected_returns.mean_historical_return(train_prices, frequency=None)
            S_t = risk_models.CovarianceShrinkage(train_prices, frequency=effective_freq).ledoit_wolf()
            sol_t = _solve_all_strategies(mu_t, S_t, train_rets, valid_tickers, weight_bounds, rf_rate, None)
            for k in strat_keys:
                new_w = pd.Series(sol_t[k]["weights"]).reindex(valid_tickers).fillna(0.0).values.astype(float)
                if new_w.sum() > 0:
                    new_w = new_w / new_w.sum()
                turnover = 0.5 * float(np.sum(np.abs(new_w - curr_w_dict[k])))
                wealth_dict[k] *= max(0.0, 1.0 - turnover * fee_rate)
                curr_w_dict[k] = new_w

        for k in strat_keys:
            asset_growth = curr_w_dict[k] * (1.0 + ret_mat[d])
            day_factor = float(asset_growth.sum())
            wealth_dict[k] *= day_factor
            if day_factor > 1e-12:
                curr_w_dict[k] = asset_growth / day_factor
            cum_arr_dict[k][d] = wealth_dict[k]

    wf_result = {k: pd.Series(cum_arr_dict[k], index=returns_df.index) for k in strat_keys}
    with _compute_cache_lock:
        if len(_wf_cache) > 64:
            _wf_cache.clear()
        _wf_cache[wf_cache_key] = (time.time(), {k: s.copy() for k, s in wf_result.items()})
    return wf_result


def run_portfolio_optimization(
    tickers: List[str],
    start_date: str,
    end_date: str,
    budget: float = 100000.0,
    max_weight: float = 1.0,
    min_weight: float = 0.0,
    risk_free_rate: Optional[float] = None,
    num_simulations: int = 3500,
    backtest_split: Optional[str] = None,
    currency: str = "THB",
    fx_rate: Optional[float] = None,
    use_news_adjustment: bool = False,
    bl_confidence: float = 0.50,
    bl_views: Optional[Dict[str, float]] = None
) -> Dict[str, Any]:
    """
    Execute full Markowitz, HRP, Monte Carlo, Walk-Forward Out-of-Sample Portfolio Growth,
    and Live Market News & Technical Intelligence.
    """
    from concurrent.futures import ThreadPoolExecutor

    # Start market news retrieval concurrently while historical prices & FX are being fetched/aligned
    clean_req_tickers = [t.strip().upper() for t in (tickers or []) if str(t).strip()]
    news_executor = ThreadPoolExecutor(max_workers=1)
    news_future = news_executor.submit(fetch_portfolio_market_news, clean_req_tickers) if clean_req_tickers else None

    try:
        prices, valid_tickers, missing_tickers = fetch_historical_prices(tickers, start_date, end_date)
        rates_meta = get_market_rates_metadata(currency=currency)

        usd_thb = float(fx_rate) if (fx_rate is not None and fx_rate > 0) else float(rates_meta["usd_thb_rate"])

        if risk_free_rate is None or risk_free_rate <= 0:
            rf_rate = float(rates_meta["risk_free_rate"])
        else:
            rf_rate = float(risk_free_rate)

        raw_last_dates = getattr(prices, "attrs", {}).get("raw_last_dates", {}) or {}
        default_last_date = prices.index[-1].strftime('%Y-%m-%d') if hasattr(prices.index[-1], 'strftime') else str(prices.index[-1])

        # Convert historical prices into a consistent base currency (THB or USD) using daily historical FX
        prices_base = convert_prices_to_base_currency(
            prices[valid_tickers],
            base_currency=currency,
            fallback_fx_rate=usd_thb
        )
        fx_history_fallback = bool(getattr(prices_base, "attrs", {}).get("fx_history_fallback", False))
        effective_freq = _infer_effective_trading_days(prices_base)

        # 1. Expected Returns (Exact Calendar CAGR) & Analytical Ledoit-Wolf Covariance Shrinkage
        mu = expected_returns.mean_historical_return(prices_base, frequency=None)
        S = risk_models.CovarianceShrinkage(prices_base, frequency=effective_freq).ledoit_wolf()
        returns_df = prices_base.pct_change().dropna()

        # Collect concurrent live market news (falls back cleanly if any ticker missed)
        news_map = news_future.result(timeout=6.0) if news_future is not None else {}
    except Exception:
        news_executor.shutdown(wait=False)
        raise
    else:
        news_executor.shutdown(wait=False)

    # Individual asset volatility from un-shrunk sample standard deviation (fixes shrunken diagonal bug)
    sample_vols_series = returns_df[valid_tickers].std(ddof=1) * np.sqrt(effective_freq)
    asset_stats = []
    latest_prices = get_latest_prices(prices)
    mu_adjusted_dict: Dict[str, float] = {}
    signal_scores_map: Dict[str, float] = {}
    all_news_articles: List[Dict[str, Any]] = []

    for i, t in enumerate(valid_tickers):
        ret_val = float(mu[t])
        vol_val = float(sample_vols_series[t])
        sr_val = (ret_val - rf_rate) / vol_val if vol_val > 0 else 0
        asset_wealth = (1 + returns_df[t]).cumprod()
        asset_dd = compute_drawdown_details(asset_wealth, budget)
        total_cum_return = float((prices_base[t].iloc[-1] / prices_base[t].iloc[0]) - 1.0)
        raw_p = float(latest_prices[t])
        native_curr = get_ticker_currency(t)
        price_thb = round(raw_p * usd_thb, 2) if native_curr == "USD" else round(raw_p, 2)
        price_usd = round(raw_p, 2) if native_curr == "USD" else (round(raw_p / usd_thb, 2) if usd_thb > 0 else round(raw_p, 2))
        price_in_budget_curr = price_thb if currency.upper() == "THB" else price_usd

        tech_info = compute_technical_signals(prices[t])
        raw_t_news = news_map.get(t, {"news_sentiment_score": 0.0, "positive_count": 0, "negative_count": 0, "neutral_count": 0, "articles": []})
        t_news = {
            "ticker": t,
            "name": get_asset_name(t),
            "news_sentiment_score": float(raw_t_news.get("news_sentiment_score", 0.0)),
            "positive_count": int(raw_t_news.get("positive_count", 0)),
            "negative_count": int(raw_t_news.get("negative_count", 0)),
            "neutral_count": int(raw_t_news.get("neutral_count", 0)),
            "articles": list(raw_t_news.get("articles", [])),
        }
        decision_info = build_asset_decision_intelligence(t, ret_val, vol_val, tech_info, t_news)

        # Guarantee every selected ticker has at least 1 actionable Market Pulse summary item if RSS returned 0 headlines
        if not t_news["articles"]:
            mom_1m_pct = float(tech_info.get("momentum_1m", 0.0)) * 100.0
            mom_3m_pct = float(tech_info.get("momentum_3m", 0.0)) * 100.0
            trend_th = tech_info.get("trend_label_th", "เคลื่อนไหวตามกรอบตลาด")
            rsi_val = float(tech_info.get("rsi_14", 50.0))
            pulse_sent = (
                "positive" if decision_info["signal_level"] == "POSITIVE_BUY"
                else ("negative" if decision_info["signal_level"] == "CAUTIOUS_SHIELD" else "neutral")
            )
            pulse_label_th = (
                "สัญญาณราคาเชิงบวก" if pulse_sent == "positive"
                else ("สัญญาณระมัดระวัง" if pulse_sent == "negative" else "สรุปความเคลื่อนไหวราคา")
            )
            is_thai_sym = t.endswith(".BK")
            search_q = f"{t.replace('.BK', '')} หุ้น" if is_thai_sym else f"{t} stock news"
            fallback_link = f"https://news.google.com/search?q={requests.utils.quote(search_q)}&hl={'th' if is_thai_sym else 'en-US'}"
            t_news["articles"] = [{
                "ticker": t,
                "title": f"สรุปความเคลื่อนไหว {get_asset_name(t)}: {trend_th} (1 เดือน {mom_1m_pct:+.1f}%, 3 เดือน {mom_3m_pct:+.1f}%, RSI {rsi_val:.0f})",
                "publisher": "QuantFolio Market Pulse (วิเคราะห์จากราคาตลาดจริง)",
                "link": fallback_link,
                "published_at": raw_last_dates.get(t, default_last_date),
                "sentiment": pulse_sent,
                "sentiment_score": float(decision_info.get("composite_signal_score", 0.0)),
                "sentiment_label_th": pulse_label_th,
                "is_market_pulse": True
            }]

        mu_adjusted_dict[t] = decision_info["adjusted_expected_return"]
        signal_scores_map[t] = decision_info["composite_signal_score"]

        div_yield_val = get_estimated_dividend_yield(t)
        asset_stats.append({
            "ticker": t,
            "name": get_asset_name(t),
            "market_type": get_asset_market_type(t),
            "native_currency": native_curr,
            "native_price": round(raw_p, 2),
            "price_thb": price_thb,
            "price_usd": price_usd,
            "latest_price": price_in_budget_curr,
            "latest_price_date": raw_last_dates.get(t, default_last_date),
            "dividend_yield": round(div_yield_val, 4),
            "dividend_included_in_total_return": True,
            "expected_return": round(ret_val, 4),
            "adjusted_expected_return": decision_info["adjusted_expected_return"],
            "return_tilt": decision_info["return_tilt"],
            "total_return": round(total_cum_return, 4),
            "volatility": round(vol_val, 4),
            "max_drawdown": asset_dd["max_drawdown_pct"],
            "max_drawdown_amount": asset_dd["max_drawdown_amount"],
            "min_capital_remaining": asset_dd["min_capital_remaining"],
            "drawdown_details": asset_dd,
            "sharpe_ratio": round(sr_val, 3),
            "technical": tech_info,
            "news": t_news,
            "decision": decision_info
        })

    mu_adjusted = pd.Series(mu_adjusted_dict).reindex(valid_tickers)

    # Sample correlation matrix directly from returns_df (fixes shrunk off-diagonal correlation distortion)
    corr_df = returns_df[valid_tickers].corr().fillna(0.0)
    for t in valid_tickers:
        corr_df.loc[t, t] = 1.0
    correlation_data = {
        "tickers": valid_tickers,
        "names": [get_asset_name(t) for t in valid_tickers],
        "matrix": [[round(float(corr_df.loc[r, c]), 4) for c in valid_tickers] for r in valid_tickers]
    }

    # 2. Optimization Models (Compute BOTH Pure Historical AND News/Trend-Adjusted)
    # Strictly validate weight constraints; impossible bounds must raise an error
    n_assets = len(valid_tickers)
    if float(max_weight) * n_assets < 1.0 - 1e-6:
        min_req = round(1.0 / n_assets, 4)
        raise ValueError(
            f"เพดานสัดส่วนสูงสุด (Max Weight = {max_weight:.0%}) รวมกันทุกสินทรัพย์ ({n_assets} ตัว = {max_weight * n_assets:.0%}) "
            f"ไม่เพียงพอให้ผลรวมครบ 100% จึงเป็นไปไม่ได้ทางคณิตศาสตร์ (ต้องการอย่างน้อย {min_req:.1%})"
        )
    if float(min_weight) * n_assets > 1.0 + 1e-6:
        raise ValueError(
            f"สัดส่วนขั้นต่ำ (Min Weight = {min_weight:.0%}) รวมกันทุกสินทรัพย์ ({n_assets} ตัว = {min_weight * n_assets:.0%}) "
            f"เกิน 100% จึงเป็นไปไม่ได้ทางคณิตศาสตร์"
        )
    if float(min_weight) > float(max_weight):
        raise ValueError(
            f"สัดส่วนขั้นต่ำ (Min Weight = {min_weight:.0%}) ต้องไม่มากกว่าเพดานสัดส่วนสูงสุด (Max Weight = {max_weight:.0%})"
        )
    effective_max_weight = float(max_weight)
    weight_bounds = (float(min_weight), effective_max_weight)

    hist_solutions = _solve_all_strategies(mu, S, returns_df, valid_tickers, weight_bounds, rf_rate, None)

    # Analytical Black-Litterman posterior (HRP Equilibrium Prior + Hybrid Auto/Manual Views + Idzorek Confidence)
    # Preserves core asset formulas (mu, S) and Min Volatility / HRP / Equal Weight 100% untouched.
    suggested_views_map = {
        a["ticker"]: round(float(a["decision"]["return_tilt"]), 4)
        for a in asset_stats
    }
    if bl_views is not None:
        effective_views_map = {
            t: round(float(np.clip(float(bl_views.get(t, 0.0)), -0.25, 0.25)), 4)
            for t in valid_tickers
        }
        views_source = "custom_hybrid"
    else:
        effective_views_map = dict(suggested_views_map)
        views_source = "auto_signal"

    bl_posterior = compute_black_litterman_posterior(
        mu_hist=mu,
        S_mat=S,
        prior_weights=hist_solutions["hrp"]["weights"],
        valid_tickers=valid_tickers,
        rf_rate=rf_rate,
        views_delta=effective_views_map,
        confidence=float(bl_confidence),
        tau=0.05
    )

    low_b, high_b = float(weight_bounds[0]), float(weight_bounds[1])
    bl_max_error = None
    try:
        ef_bl = EfficientFrontier(bl_posterior["mu_bl"], bl_posterior["Sigma_bl"], weight_bounds=weight_bounds)
        ef_bl.max_sharpe(risk_free_rate=rf_rate)
        w_bl_max = _cap_and_normalize_weights(ef_bl.clean_weights(), valid_tickers, low_b, high_b)
        w_bl_s = pd.Series(w_bl_max).reindex(valid_tickers).fillna(0.0)
        ret_bl_max = float(w_bl_s @ bl_posterior["mu_bl"])
        vol_bl_max = float(np.sqrt(max(1e-12, w_bl_s @ bl_posterior["Sigma_bl"] @ w_bl_s)))
        sr_bl_max = (ret_bl_max - rf_rate) / vol_bl_max if vol_bl_max > 0 else 0.0
    except Exception as e:
        bl_max_error = str(e)
        w_bl_max = dict(hist_solutions["hrp"]["weights"])
        w_bl_s = pd.Series(w_bl_max).reindex(valid_tickers).fillna(0.0)
        ret_bl_max = float(w_bl_s @ bl_posterior["mu_bl"])
        vol_bl_max = float(np.sqrt(max(1e-12, w_bl_s @ bl_posterior["Sigma_bl"] @ w_bl_s)))
        sr_bl_max = (ret_bl_max - rf_rate) / vol_bl_max if vol_bl_max > 0 else 0.0

    # Min Volatility, HRP, and Equal Weight stay 100% identical to pure historical (mu, S)
    adj_solutions = {
        "max_sharpe": {"weights": w_bl_max, "ret": ret_bl_max, "vol": vol_bl_max, "sr": sr_bl_max, "error": bl_max_error},
        "min_volatility": dict(hist_solutions["min_volatility"]),
        "hrp": dict(hist_solutions["hrp"]),
        "equal_weight": dict(hist_solutions["equal_weight"])
    }

    active_solutions = adj_solutions if use_news_adjustment else hist_solutions

    w_max = active_solutions["max_sharpe"]["weights"]
    ret_max, vol_max, sr_max = active_solutions["max_sharpe"]["ret"], active_solutions["max_sharpe"]["vol"], active_solutions["max_sharpe"]["sr"]
    max_sharpe_error = active_solutions["max_sharpe"]["error"]
    da_max = compute_discrete_allocation(w_max, latest_prices, budget, currency, usd_thb)

    w_min = active_solutions["min_volatility"]["weights"]
    ret_min, vol_min, sr_min = active_solutions["min_volatility"]["ret"], active_solutions["min_volatility"]["vol"], active_solutions["min_volatility"]["sr"]
    da_min = compute_discrete_allocation(w_min, latest_prices, budget, currency, usd_thb)

    w_hrp = active_solutions["hrp"]["weights"]
    ret_hrp, vol_hrp, sr_hrp = active_solutions["hrp"]["ret"], active_solutions["hrp"]["vol"], active_solutions["hrp"]["sr"]
    da_hrp = compute_discrete_allocation(w_hrp, latest_prices, budget, currency, usd_thb)

    w_eq = active_solutions["equal_weight"]["weights"]
    ret_eq, vol_eq, sr_eq = active_solutions["equal_weight"]["ret"], active_solutions["equal_weight"]["vol"], active_solutions["equal_weight"]["sr"]
    da_eq = compute_discrete_allocation(w_eq, latest_prices, budget, currency, usd_thb)

    # 3. Historical Portfolio Wealth Simulation & Drawdown Analytics (Quarterly Rebalance + 15 bps Fee + Walk-Forward)
    strat_weights_map = {
        "max_sharpe": pd.Series(w_max),
        "min_volatility": pd.Series(w_min),
        "hrp": pd.Series(w_hrp),
        "equal_weight": pd.Series(w_eq)
    }

    wf_curves = compute_walk_forward_backtest(
        prices_base=prices_base,
        valid_tickers=valid_tickers,
        weight_bounds=weight_bounds,
        rf_rate=rf_rate,
        effective_freq=effective_freq,
        backtest_split=backtest_split,
        rebalance_every=63,
        fee_bps=15.0
    )

    strat_wealth_df = pd.DataFrame(index=returns_df.index)
    strat_wf_wealth_df = pd.DataFrame(index=returns_df.index)
    strat_dd_amount_df = pd.DataFrame(index=returns_df.index)
    strat_drawdowns = {}
    strat_dd_details = {}
    strat_final_values = {}
    strat_div_yields = {}

    for key, w_s in strat_weights_map.items():
        w_aligned = w_s.reindex(valid_tickers).fillna(0.0)
        cum_growth = simulate_drifting_backtest_with_fees(
            returns_df[valid_tickers],
            w_aligned,
            rebalance_every=63,
            fee_bps=15.0
        )
        wf_cum_growth = wf_curves.get(key, cum_growth)
        strat_wealth_df[key] = (cum_growth * budget).round(2)
        strat_wf_wealth_df[key] = (wf_cum_growth * budget).round(2)

        running_max = cum_growth.cummax().clip(lower=1.0)
        dd_pct_series = (cum_growth - running_max) / running_max
        # Actual peak-to-trough monetary drawdown series from running peak wealth
        strat_dd_amount_df[key] = ((cum_growth - running_max) * budget).round(2)

        dd_info = compute_drawdown_details(cum_growth, budget)
        strat_drawdowns[key] = dd_info["max_drawdown_pct"]
        strat_dd_details[key] = dd_info
        strat_final_values[key] = round(float(strat_wealth_df[key].iloc[-1]), 2)
        strat_div_yields[key] = round(float(sum(float(w_aligned[t]) * get_estimated_dividend_yield(t) for t in valid_tickers)), 4)

    step = max(1, len(strat_wealth_df) // 160)
    sampled_wealth = strat_wealth_df.iloc[::step]
    sampled_wf_wealth = strat_wf_wealth_df.iloc[::step]
    sampled_dd_amount = strat_dd_amount_df.iloc[::step]
    if strat_wealth_df.index[-1] not in sampled_wealth.index:
        sampled_wealth = pd.concat([sampled_wealth, strat_wealth_df.iloc[[-1]]])
        sampled_wf_wealth = pd.concat([sampled_wf_wealth, strat_wf_wealth_df.iloc[[-1]]])
        sampled_dd_amount = pd.concat([sampled_dd_amount, strat_dd_amount_df.iloc[[-1]]])

    portfolio_growth_chart = {
        "dates": [d.strftime('%Y-%m-%d') for d in sampled_wealth.index],
        "rebalance_assumption": f"ปรับสมดุลพอร์ตทุก 63 วันข้อมูล (ปฏิทิน {effective_freq} วัน/ปี) หักค่าธรรมเนียมซื้อขาย 0.15%",
        "series": {
            k: sampled_wealth[k].tolist() for k in strat_weights_map.keys()
        },
        "walk_forward_series": {
            k: sampled_wf_wealth[k].tolist() for k in strat_weights_map.keys()
        },
        "drawdown_amount_series": {
            k: sampled_dd_amount[k].tolist() for k in strat_weights_map.keys()
        }
    }

    # 4. Monte Carlo Random Portfolios for Efficient Frontier
    rng = np.random.default_rng(42)
    W_rand = rng.dirichlet(np.ones(len(valid_tickers)), num_simulations)
    valid_mask = (
        (W_rand >= (float(min_weight) - 1e-6)).all(axis=1)
        & (W_rand <= (effective_max_weight + 1e-6)).all(axis=1)
    )
    if valid_mask.sum() > 200:
        W_rand = W_rand[valid_mask]

    rand_rets = (W_rand * mu.values).sum(axis=1)
    rand_vols = np.sqrt(np.einsum('ij,jk,ik->i', W_rand, S.values, W_rand))
    rand_sr = np.where(rand_vols > 0, (rand_rets - rf_rate) / rand_vols, 0)

    sample_size = min(len(rand_rets), 1800)
    indices = np.linspace(0, len(rand_rets) - 1, sample_size, dtype=int)

    monte_carlo_points = [
        {
            "vol": round(float(rand_vols[idx]), 4),
            "ret": round(float(rand_rets[idx]), 4),
            "sharpe": round(float(rand_sr[idx]), 3)
        }
        for idx in indices
    ]

    frontier_curve = []
    try:
        min_target = float(ret_min)
        max_target = float(ret_min + 0.95 * (mu.max() - ret_min))
        if max_target > min_target:
            frontier_cache_key = (
                tuple(valid_tickers),
                str(prices_base.index[0]),
                str(prices_base.index[-1]),
                int(len(prices_base)),
                round(float(prices_base[valid_tickers].iloc[0].sum()), 6),
                round(float(prices_base[valid_tickers].iloc[-1].sum()), 6),
                (round(float(weight_bounds[0]), 6), round(float(weight_bounds[1]), 6)),
                round(float(rf_rate), 6),
                round(min_target, 6),
                round(max_target, 6),
            )
            now_fc = time.time()
            cached_fc = None
            with _compute_cache_lock:
                entry = _frontier_cache.get(frontier_cache_key)
                if entry is not None and (now_fc - entry[0] < COMPUTE_CACHE_TTL):
                    cached_fc = [dict(pt) for pt in entry[1]]

            if cached_fc is not None:
                frontier_curve = cached_fc
            else:
                target_returns = np.linspace(min_target, max_target, 35)
                ef_batch = EfficientFrontier(mu, S, weight_bounds=weight_bounds)
                if hasattr(ef_batch, "efficient_return_batch"):
                    frontier_curve = ef_batch.efficient_return_batch(target_returns, risk_free_rate=rf_rate)
                else:
                    for tr in target_returns:
                        try:
                            ef_curve = EfficientFrontier(mu, S, weight_bounds=weight_bounds)
                            ef_curve.efficient_return(tr)
                            r_perf, v_perf, s_perf = ef_curve.portfolio_performance(risk_free_rate=rf_rate)
                            frontier_curve.append({
                                "vol": round(float(v_perf), 4),
                                "ret": round(float(r_perf), 4),
                                "sharpe": round(float(s_perf), 3)
                            })
                        except Exception:
                            continue
                with _compute_cache_lock:
                    if len(_frontier_cache) > 64:
                        _frontier_cache.clear()
                    _frontier_cache[frontier_cache_key] = (time.time(), [dict(pt) for pt in frontier_curve])
    except Exception:
        pass

    growth_100 = (prices_base / prices_base.iloc[0] * 100).round(2)
    growth_sampled = growth_100.iloc[::step]
    if growth_100.index[-1] not in growth_sampled.index:
        growth_sampled = pd.concat([growth_sampled, growth_100.iloc[[-1]]])

    growth_chart_data = {
        "dates": [d.strftime('%Y-%m-%d') for d in growth_sampled.index],
        "series": {t: growth_sampled[t].tolist() for t in valid_tickers}
    }

    cov_matrix_data = {
        "tickers": valid_tickers,
        "matrix": [[round(float(S.loc[r, c]), 6) for c in valid_tickers] for r in valid_tickers]
    }

    # Interleave articles round-robin across ALL valid_tickers so every selected stock is represented fairly
    max_art_len = max((len(a["news"].get("articles", [])) for a in asset_stats), default=0)
    for pass_idx in range(max_art_len):
        for a in asset_stats:
            arts = a["news"].get("articles", [])
            if pass_idx < len(arts):
                all_news_articles.append(arts[pass_idx])

    pos_assets = [a["ticker"] for a in asset_stats if a["decision"]["signal_level"] == "POSITIVE_BUY"]
    caution_assets = [a["ticker"] for a in asset_stats if a["decision"]["signal_level"] in ("CAUTIOUS_SHIELD", "OVERBOUGHT_TRANCHE")]

    market_intelligence = {
        "use_news_adjustment": bool(use_news_adjustment),
        "positive_signal_tickers": pos_assets,
        "caution_signal_tickers": caution_assets,
        "total_articles_analyzed": len(all_news_articles),
        "articles": all_news_articles[:max(24, len(valid_tickers) * 4)]
    }

    black_litterman_data = {
        "enabled": bool(use_news_adjustment),
        "model": "He-Litterman + Idzorek (2005)",
        "prior_source": "hrp_equilibrium",
        "views_source": views_source,
        "tau": bl_posterior["tau"],
        "risk_aversion_delta": bl_posterior["delta"],
        "confidence": bl_posterior["confidence"],
        "active_view_count": bl_posterior["active_view_count"],
        "prior_weights": {k: round(float(v), 4) for k, v in hist_solutions["hrp"]["weights"].items()},
        "posterior_weights": {k: round(float(v), 4) for k, v in adj_solutions["max_sharpe"]["weights"].items()},
        "prior_returns": {t: round(float(bl_posterior["pi_total"][t]), 4) for t in valid_tickers},
        "posterior_returns": {t: round(float(bl_posterior["mu_bl"][t]), 4) for t in valid_tickers},
        "suggested_views": suggested_views_map,
        "applied_views": bl_posterior["applied_views"]
    }

    return {
        "status": "success",
        "metadata": {
            "tickers": valid_tickers,
            "missing_tickers": missing_tickers,
            "start_date": prices.index[0].strftime('%Y-%m-%d'),
            "end_date": prices.index[-1].strftime('%Y-%m-%d'),
            "trading_days": len(prices),
            "aligned_row_count": len(prices),
            "alignment_method": "union_ffill_limit5",
            "effective_annual_days": effective_freq,
            "risk_free_rate": round(rf_rate, 4),
            "risk_free_source": rates_meta.get("risk_free_source"),
            "risk_free_tenor": rates_meta.get("risk_free_tenor"),
            "risk_free_date": rates_meta.get("risk_free_date"),
            "rf_updated_at": rates_meta.get("rf_updated_at"),
            "budget": budget,
            "currency": currency.upper(),
            "usd_thb_rate": usd_thb,
            "fx_date": rates_meta.get("fx_date"),
            "fx_updated_at": rates_meta.get("fx_updated_at"),
            "fx_is_daily_history_fallback": fx_history_fallback,
            "is_fallback_fx": bool(_last_fx_is_fallback or (fx_rate is None and rates_meta.get("is_fallback_fx"))),
            "is_fallback_rf": bool(_last_rf_is_fallback or (risk_free_rate is None and rates_meta.get("is_fallback_rf"))),
            "data_as_of": default_last_date,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
            "model_version": "QuantFolio-v2.4.0",
            "max_weight": effective_max_weight,
            "use_news_adjustment": bool(use_news_adjustment),
            "bl_confidence": bl_posterior["confidence"],
            "rebalance_assumption": "ปรับสมดุลพอร์ตทุก 63 วันข้อมูล หักค่าธรรมเนียมซื้อขาย 0.15%",
            "walk_forward_out_of_sample": True,
            "dividend_included_in_total_return": True
        },
        "asset_stats": asset_stats,
        "correlation": correlation_data,
        "covariance": cov_matrix_data,
        "black_litterman": black_litterman_data,
        "market_intelligence": market_intelligence,
        "growth_100": growth_chart_data,
        "portfolio_growth": portfolio_growth_chart,
        "strategies": {
            "max_sharpe": {
                "key": "max_sharpe",
                "name": "พอร์ตผลตอบแทนคุ้มความเสี่ยงสูงสุด (Max Sharpe)",
                "short_name": "Max Sharpe Ratio",
                "tagline": "เหมาะสำหรับผู้ที่ต้องการผลตอบแทนเติบโตสูงสุดเมื่อเทียบกับความเสี่ยงที่รับได้",
                "weights": {k: round(float(v), 4) for k, v in w_max.items()},
                "historical_weights": {k: round(float(v), 4) for k, v in hist_solutions["max_sharpe"]["weights"].items()},
                "news_adjusted_weights": {k: round(float(v), 4) for k, v in adj_solutions["max_sharpe"]["weights"].items()},
                "historical_metrics": {
                    "expected_return": round(float(hist_solutions["max_sharpe"]["ret"]), 4),
                    "volatility": round(float(hist_solutions["max_sharpe"]["vol"]), 4),
                    "sharpe_ratio": round(float(hist_solutions["max_sharpe"]["sr"]), 2)
                },
                "news_adjusted_metrics": {
                    "expected_return": round(float(adj_solutions["max_sharpe"]["ret"]), 4),
                    "volatility": round(float(adj_solutions["max_sharpe"]["vol"]), 4),
                    "sharpe_ratio": round(float(adj_solutions["max_sharpe"]["sr"]), 2)
                },
                "expected_return": round(float(ret_max), 4),
                "expected_annual_profit": round(float(ret_max * budget), 2),
                "dividend_yield": strat_div_yields["max_sharpe"],
                "expected_annual_dividend": round(float(strat_div_yields["max_sharpe"] * budget), 2),
                "volatility": round(float(vol_max), 4),
                "max_drawdown": strat_drawdowns["max_sharpe"],
                "max_drawdown_amount": strat_dd_details["max_sharpe"]["max_drawdown_amount"],
                "min_capital_remaining": strat_dd_details["max_sharpe"]["min_capital_remaining"],
                "drawdown_details": strat_dd_details["max_sharpe"],
                "final_historical_value": strat_final_values["max_sharpe"],
                "sharpe_ratio": round(float(sr_max), 2),
                "discrete_allocation": da_max,
                "error_notice": max_sharpe_error
            },
            "min_volatility": {
                "key": "min_volatility",
                "name": "พอร์ตความเสี่ยงต่ำ ผันผวนน้อย (Min Volatility)",
                "short_name": "Min Volatility",
                "tagline": "เหมาะสำหรับผู้ที่เน้นรักษาเงินต้น ลดการแกว่งตัวของพอร์ตในช่วงตลาดผันผวน",
                "weights": {k: round(float(v), 4) for k, v in w_min.items()},
                "historical_weights": {k: round(float(v), 4) for k, v in hist_solutions["min_volatility"]["weights"].items()},
                "news_adjusted_weights": {k: round(float(v), 4) for k, v in adj_solutions["min_volatility"]["weights"].items()},
                "historical_metrics": {
                    "expected_return": round(float(hist_solutions["min_volatility"]["ret"]), 4),
                    "volatility": round(float(hist_solutions["min_volatility"]["vol"]), 4),
                    "sharpe_ratio": round(float(hist_solutions["min_volatility"]["sr"]), 2)
                },
                "news_adjusted_metrics": {
                    "expected_return": round(float(adj_solutions["min_volatility"]["ret"]), 4),
                    "volatility": round(float(adj_solutions["min_volatility"]["vol"]), 4),
                    "sharpe_ratio": round(float(adj_solutions["min_volatility"]["sr"]), 2)
                },
                "expected_return": round(float(ret_min), 4),
                "expected_annual_profit": round(float(ret_min * budget), 2),
                "dividend_yield": strat_div_yields["min_volatility"],
                "expected_annual_dividend": round(float(strat_div_yields["min_volatility"] * budget), 2),
                "volatility": round(float(vol_min), 4),
                "max_drawdown": strat_drawdowns["min_volatility"],
                "max_drawdown_amount": strat_dd_details["min_volatility"]["max_drawdown_amount"],
                "min_capital_remaining": strat_dd_details["min_volatility"]["min_capital_remaining"],
                "drawdown_details": strat_dd_details["min_volatility"],
                "final_historical_value": strat_final_values["min_volatility"],
                "sharpe_ratio": round(float(sr_min), 2),
                "discrete_allocation": da_min
            },
            "hrp": {
                "key": "hrp",
                "name": "พอร์ตกระจายความเสี่ยงสมดุล (Risk Parity / HRP)",
                "short_name": "Risk Parity (HRP)",
                "tagline": "จัดกลุ่มสินทรัพย์ด้วย Machine Learning เพื่อกระจายความเสี่ยงอย่างสมดุล ไม่กระจุกตัว",
                "weights": {k: round(float(v), 4) for k, v in w_hrp.items()},
                "historical_weights": {k: round(float(v), 4) for k, v in hist_solutions["hrp"]["weights"].items()},
                "news_adjusted_weights": {k: round(float(v), 4) for k, v in adj_solutions["hrp"]["weights"].items()},
                "historical_metrics": {
                    "expected_return": round(float(hist_solutions["hrp"]["ret"]), 4),
                    "volatility": round(float(hist_solutions["hrp"]["vol"]), 4),
                    "sharpe_ratio": round(float(hist_solutions["hrp"]["sr"]), 2)
                },
                "news_adjusted_metrics": {
                    "expected_return": round(float(adj_solutions["hrp"]["ret"]), 4),
                    "volatility": round(float(adj_solutions["hrp"]["vol"]), 4),
                    "sharpe_ratio": round(float(adj_solutions["hrp"]["sr"]), 2)
                },
                "expected_return": round(float(ret_hrp), 4),
                "expected_annual_profit": round(float(ret_hrp * budget), 2),
                "dividend_yield": strat_div_yields["hrp"],
                "expected_annual_dividend": round(float(strat_div_yields["hrp"] * budget), 2),
                "volatility": round(float(vol_hrp), 4),
                "max_drawdown": strat_drawdowns["hrp"],
                "max_drawdown_amount": strat_dd_details["hrp"]["max_drawdown_amount"],
                "min_capital_remaining": strat_dd_details["hrp"]["min_capital_remaining"],
                "drawdown_details": strat_dd_details["hrp"],
                "final_historical_value": strat_final_values["hrp"],
                "sharpe_ratio": round(float(sr_hrp), 2),
                "discrete_allocation": da_hrp
            },
            "equal_weight": {
                "key": "equal_weight",
                "name": "พอร์ตลงทุนสัดส่วนเท่ากัน (Equal Weight 1/N)",
                "short_name": "Equal Weight (1/N)",
                "tagline": "แบ่งเงินลงทุนเท่ากันในสินทรัพย์ทุกตัว ใช้เป็นเกณฑ์มาตรฐานเปรียบเทียบ",
                "weights": {k: round(float(v), 4) for k, v in w_eq.items()},
                "historical_weights": {k: round(float(v), 4) for k, v in hist_solutions["equal_weight"]["weights"].items()},
                "news_adjusted_weights": {k: round(float(v), 4) for k, v in adj_solutions["equal_weight"]["weights"].items()},
                "historical_metrics": {
                    "expected_return": round(float(hist_solutions["equal_weight"]["ret"]), 4),
                    "volatility": round(float(hist_solutions["equal_weight"]["vol"]), 4),
                    "sharpe_ratio": round(float(hist_solutions["equal_weight"]["sr"]), 2)
                },
                "news_adjusted_metrics": {
                    "expected_return": round(float(adj_solutions["equal_weight"]["ret"]), 4),
                    "volatility": round(float(adj_solutions["equal_weight"]["vol"]), 4),
                    "sharpe_ratio": round(float(adj_solutions["equal_weight"]["sr"]), 2)
                },
                "expected_return": round(float(ret_eq), 4),
                "expected_annual_profit": round(float(ret_eq * budget), 2),
                "dividend_yield": strat_div_yields["equal_weight"],
                "expected_annual_dividend": round(float(strat_div_yields["equal_weight"] * budget), 2),
                "volatility": round(float(vol_eq), 4),
                "max_drawdown": strat_drawdowns["equal_weight"],
                "max_drawdown_amount": strat_dd_details["equal_weight"]["max_drawdown_amount"],
                "min_capital_remaining": strat_dd_details["equal_weight"]["min_capital_remaining"],
                "drawdown_details": strat_dd_details["equal_weight"],
                "final_historical_value": strat_final_values["equal_weight"],
                "sharpe_ratio": round(float(sr_eq), 2),
                "discrete_allocation": da_eq
            }
        },
        "efficient_frontier": {
            "monte_carlo": monte_carlo_points,
            "curve": frontier_curve
        }
    }
